<?php $__env->startSection('title','Điểm danh chương trình'); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/admin/activity/list_activity.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="row">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
            <li class="breadcrumb-item"><i class="fas fa-angle-right"></i> Quản lý ĐRL - CTXH</li>
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Tạo danh sách cộng điểm</li>
        </ol>
    </nav>
</div>
<div class="row">
  <div class="col page-title-header">
    <h4>Tạo danh sách cộng điểm</h4>
  </div>
</div>
<form action="<?php echo e(route('post_add_marks')); ?>" method="POST" id="myform">
  <?php echo csrf_field(); ?>
  <div class="row">
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <div class="form-row">
        
        <div class="form-group col-md-4">
          <label for="content" class="col-md-12 col-sm-12 col-xs-12 common-label-inline">Nội dung danh sách <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
          <div class="col-md-8 col-sm-8 col-xs-8 px-0">
            <input name="content" id="content" class="form-control" placeholder="Nhập nội dung danh sách điểm cộng" required>
          </div>
        </div>
        
        
        <div class="form-group col-md-4">
          <label for="type" class="col-md-12 col-sm-12 col-xs-12 common-label-inline">Loại điểm cộng <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
          <div class="col-md-8 col-sm-8 col-xs-8 px-0">
            <select name="type" id="type" class="form-control" required>
              <option value="">Chọn loại điểm</option>
              <option value="0">Điểm rèn luyện</option>
              <option value="1">Điểm CTXH</option>
            </select>
          </div>
        </div>
        
        
        <div class="form-group col-md-4">
          <label for="marks" class="col-md-12 col-sm-12 col-xs-12 common-label-inline">Số điểm cộng <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
          <div class="col-md-8 col-sm-8 col-xs-8 px-0">
            <input type="number" name="marks" id="marks" class="form-control" placeholder="Nhập số điểm cộng" required>
          </div>
        </div>
      </div>
      
      <div class="form-row">
        
        <?php if($errors->get('content')): ?>
        <div class="form-group col-md-4 cm-inline-form cm-error">
          <ul class="col-md-8 cm-ul-error">
            <?php $__currentLoopData = $errors->get('content'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($sid); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
        
        
        <?php if($errors->get('type')): ?>
        <div class="form-group col-md-4 cm-inline-form cm-error">
          <ul class="col-md-8 cm-ul-error">
            <?php $__currentLoopData = $errors->get('type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($sid); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
        
        
        <?php if($errors->get('marks')): ?>
        <div class="form-group col-md-4 cm-inline-form cm-error">
          <ul class="col-md-8 cm-ul-error">
            <?php $__currentLoopData = $errors->get('marks'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($sid); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
        <?php endif; ?>
      </div>
      
      <div class="form-row">
        
        <div class="form-group col-md-4">
          <label for="year" class="col-md-4 common-label-inline">Năm học:</label>
          <div class="col-md-8 col-sm-8 col-xs-8 px-0">
            <select name="year" id="year" class="form-control">
              <option value="<?php echo e($year->name); ?>"><?php echo e($year->name); ?></option>
            </select>
          </div>
        </div>
        
        
        <div class="form-group col-md-4">
          <label for="activity" class="col-md-4 common-label-inline">Chương trình:</label>
          <div class="col-md-8 col-sm-8 col-xs-8 px-0">
            <select name="activity" id="activity" class="form-control">
              <option value="">Chọn chương trình</option>
              <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        <input type="hidden" name="data" id="data">
      </div>
    </div>
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <div class="row">
        <div class="col-md-4">
          <div class="card mb-4">
            <div class="card-body">
              <div class="form-group">
                <input type="number" class="form-control" id="inputsid" placeholder="Nhập MSSV sau đó nhấn Enter" min="1" max="99999999">
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-8">
          <!-- Begin Page Content -->
          <div class="card mb-4">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                  <thead style="background: #f8f9fc">
                    <tr>
                      <th>STT</th>
                      <th>MSSV</th>
                      <th>Tên Sinh viên</th>
                      <th>Thời gian checkin</th>
                    </tr>
                  </thead>
                  <tbody>
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="text-right">
            <button class="btn btn-primary cm-btn-form" id="saveinfo" type="submit"><i class="fas fa-download"></i> Lưu</button>
          </div>
        </div>
      </div>
    </div>
  </div>
</form>

<div class="col-md-12">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb cm-breadcrumb">
      <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
      
    </ol>
  </nav>
</div>
<!-- Modal -->
<div class="modal animated jackInTheBox" id="activityDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Page level plugins -->
<script>
  var BASE_URL = "<?php echo e(asset('admin/activities/')); ?>";
  var students = <?php echo $students; ?>;
  <?php if(session('error')): ?>
  var error = "<?php echo e(session('error')); ?>";
  showNotify('error',error);
<?php endif; ?>
<?php if(session('success')): ?>
  var success = "<?php echo e(session('success')); ?>";
  showNotify('success',success);
<?php endif; ?>
</script>
<script src="<?php echo e(asset('assets/js/admin/ac_marks/add_marks.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/ac_marks/add_marks.blade.php */ ?>