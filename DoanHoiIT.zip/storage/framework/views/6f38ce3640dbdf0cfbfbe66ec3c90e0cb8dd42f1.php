<div class="col-md-3">
				<div class="profile-sidebar">
					<!-- SIDEBAR USERPIC -->
					<div class="profile-userpic">
						<img src="<?php echo e(asset('assets/img/students/'.Auth::user()->student->image)); ?>" class="img-responsive" alt="">
					</div>
					<!-- END SIDEBAR USERPIC -->
					<!-- SIDEBAR USER TITLE -->
					<div class="profile-usertitle">
						<div class="profile-usertitle-name">
							<?php echo e(Auth::user()->student->name); ?>

						</div>
						<div class="profile-usertitle-job">
							
						</div>
					</div>
					<!-- END SIDEBAR USER TITLE -->
					<!-- SIDEBAR BUTTONS -->

					<!-- END SIDEBAR BUTTONS -->
					<!-- SIDEBAR MENU -->
					<div class="profile-usermenu">
						<ul class="nav">
							<li <?php if($status === "info"): ?><?php echo 'class="active"'; ?> <?php endif; ?>>
								<a href="">
									<i class="glyphicon glyphicon-home"></i>
								Thông tin chung </a>
							</li>
	
							<li <?php if($status === "changepass"): ?><?php echo 'class="active"'; ?> <?php endif; ?>>
								<a href="<?php echo e(route('get_user_change_pass')); ?>">
									<i class="glyphicon glyphicon-wrench"></i>
								Đổi mật khẩu</a>
							</li>

							<li <?php if($status === "registedac"): ?><?php echo 'class="active"'; ?> <?php endif; ?>>
									<a href="<?php echo e(route('get_registed_ac')); ?>">
										<i class="	glyphicon glyphicon-list-alt"></i>
									Chương trình đã đăng ký</a>
							</li>
	
						</ul>
					</div>
					<!-- END MENU -->
				</div>
			</div>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/layout/usersidebar.blade.php */ ?>