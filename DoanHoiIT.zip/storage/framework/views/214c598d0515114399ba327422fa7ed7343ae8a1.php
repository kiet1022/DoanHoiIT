<?php $__env->startSection('title'); ?>
<?php echo e("Các chương trình đã đăng ký"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="container">
	<ol class="breadcrumb" style="background-color: #ffffff; margin-bottom: 0px; border-left: 5px solid #4e73df;">
		<li><a href="<?php echo e(route('get_home_page')); ?>" class="text-info">Trang chủ</a></li>
    <li>Các chương trình đã đăng ký</li>
	</ol>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9" style="background: white; padding-top: 30px;">	
  <div class="col-md-12" style="min-height: 437px;">
    <?php if(count($attended) > 0): ?>
    <table class="table table-hover">
        <thead>
          <tr>
            <th>Tên chương trình</th>
            <th>Thời gian</th>
            <th>Số lượng SV đăng ký</th>
            <th>Điểm cộng</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $attended; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
              <td><?php echo e($at->ofActivity->name); ?></td>
              <td><?php echo e(date('d/m/Y',strtotime($at->ofActivity->start_date))); ?> - <?php echo e(date('d/m/Y',strtotime($at->ofActivity->end_date))); ?></td>
              <td><?php echo e($at->ofActivity->register_number); ?></td>
              <td>
                  <?php if($at->ofActivity->practise_marks > 0): ?>
                  <?php echo e($at->ofActivity->practise_marks); ?> ĐRL
              <?php elseif($at->ofActivity->social_marks > 0): ?>
                <?php echo e($at->ofActivity->practise_marks); ?> Điểm CTXH
              <?php endif; ?>
              </td>
              <td>                  
                <form action="<?php echo e(route('cancel_regis_activity')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="activity_id" value="<?php echo e($at->ofActivity->id); ?>">
                  <button class="btn btn-danger btn-sm" type="submit">Hủy đăng ký</button>
              </form>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    <?php else: ?>
      <div class="text-center">
          <span class="label label-warning" style="font-size: 100%">Bạn chưa đăng ký tham gia chương trình nào.</span>
      </div>
    <?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
	$('form').on('submit', function(){
		blockUI(true);
	})

	<?php if(session('error')): ?>
    var error = "<?php echo e(session('error')); ?>";
    showNotify('error',error);
    <?php endif; ?>
    <?php if(session('success')): ?>
    var success = "<?php echo e(session('success')); ?>";
    console.log(success)
    showNotify('success',success);
    <?php endif; ?>

    $('form').on('submit', function(){
      blockUI(true);
    });
</script>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layout.userindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/registerd_activity.blade.php */ ?>