<?php /* D:\xampp\htdocs\DoanHoi\resources\views/admin/news/add_new.blade.php */ ?>
<?php $__env->startSection('title'); ?>
Thêm bài viết
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/admin/common.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/vendor/icheck-1.x/skins/flat/green.css')); ?>" rel="stylesheet">
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/gijgo-combined-1.9.11/css/gijgo.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="row">
    <div class="col page-title-header">
        <h4>Thêm bài viết</h4>
    </div>
</div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
        <form action="<?php echo e(route('post_add_new')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">       
                            <div class="form-inline cm-inline-form">
                                <label for="type" class="col-md-2 common-label-inline">Loại tin:</label>
                                <select id="type" class="form-control col-md-4" name="type">
                                    <?php $__currentLoopData = $newsType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo $type->id; ?>" <?php echo e(changeSelectedStatus("$type->id",old('type'))); ?>><?php echo e($type->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-inline cm-inline-form">
                                <label for="title" class="col-md-2 common-label-inline">Tiêu đề <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <input type="text" class="form-control col-md-8" id="title" name="title" placeholder="" required value="<?php echo e(old('title')); ?>">
                            </div>                     
                            <div class="form-inline cm-inline-form">
                                <label for="sumary" class="col-md-2 common-label-inline">Tóm tắt:</label>
                                <textarea class="col-md-8"  id="sumary" name="sumary" style="margin-top: 0px; margin-bottom: 0px; height: 139px;"></textarea>
                            </div>
                            <div class="form-inline cm-inline-form">
                                <label for="content_news" class="col-md-2 common-label-inline">Nội dung <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <textarea id="content_news" name="content_news"></textarea>
                            </div>
                            <div class="form-inline cm-inline-form">
                                <label  class="col-md-2 common-label-inline">Hình ảnh nổi bật:</label>
                                <input type="file" name="image" id="image" onchange="loadFile(event)">
                                <img class="image-new" id="output"/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="sidebar-divider">
            <div class="col-12 text-center">
                <button type="button" class="btn btn-secondary cm-btn-form" onclick="javascript:history.back()">Cancel</button>
                <button type="submit" class="btn btn-success cm-btn-form">Submit</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/vendor/icheck-1.x/icheck.js')); ?>"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<script src="<?php echo e(asset('assets/vendor/gijgo-combined-1.9.11/js/gijgo.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/admin/news.js')); ?>"></script>
<script type="text/javascript">
    //replace textarea
if(CKEDITOR) {
    CKEDITOR.replace('content_news', {
        allowedContent: true
    });
    CKEDITOR.config.extraAllowedContent = 'audio[*]';
    CKEDITOR.config.height = 350;
    CKEDITOR.config.width = 350;
}
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>