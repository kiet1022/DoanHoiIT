<?php $__env->startSection('title'); ?>
Thông tin sinh viên
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="row">
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
      <li class="breadcrumb-item"><i class="fas fa-angle-right"></i> Quản lý sinh viên</li>
      <li class="breadcrumb-item"><i class="fas fa-angle-right"></i><a href="<?php echo e(route('get_student_list')); ?>"> Danh sách sinh viên</a></li>
      <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Chỉnh sửa thông tin</li>
    </ol>
  </nav>
</div>
<div class="row">
  <div class="col-12 page-title-header">
    <h4>Nhập thông tin sinh viên</h4>
  </div>
</div>
<div class="row">
  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 custom_panel">
    <form id="formEditStudent" action="<?php echo e(route('post_edit_student',['id'=>$student->student_id])); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="form-row">
        
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
          <div class="card">
            <div class="card-header">
              <b>Thông tin cơ bản</b>
            </div>
            <div class="card-body">
              
              <div class="form-inline cm-inline-form">
                <label for="sid" class="col-md-4 common-label-inline">MSSV <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                <input type="number" class="form-control col-md-8" id="sid" name="sid" placeholder="Mã số sinh viên" readonly value="<?php echo e($student->student_id); ?>">
              </div>
              
              
              <?php if($errors->get('sid')): ?>
              <div class="form-inline cm-inline-form cm-error">
                <ul class="col-md-8 offset-md-4 cm-ul-error">
                  <?php $__currentLoopData = $errors->get('sid'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($sid); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
              
              
              <div class="form-inline cm-inline-form">
                <label for="studentName" class="col-md-4 common-label-inline">Họ tên <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                <input type="text" class="form-control col-md-8" id="studentName" name="studentName" placeholder="Họ và Tên" required <?php if($errors->any()): ?> value="<?php echo e(old('studentName')); ?>" <?php else: ?>  value="<?php echo e($student->name); ?>"  <?php endif; ?> >
              </div>
              
              
              <?php if($errors->get('studentName')): ?>
              <div class="form-inline cm-inline-form cm-error">
                <ul class="col-md-8 offset-md-4 cm-ul-error">
                  <?php $__currentLoopData = $errors->get('studentName'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($studentName); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
              
              
              <div class="form-inline cm-inline-form">
                <label for="studentSex" class="col-md-4 common-label-inline">Giới tính <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                <select id="studentSex" class="form-control col-md-8" name="studentSex" required >
                  <option value="1" <?php echo e(changeSelectedStatus("1","$student->sex")); ?>>Nam</option>
                  <option value="2" <?php echo e(changeSelectedStatus("2","$student->sex")); ?>>Nữ</option>
                  <option value="3" <?php echo e(changeSelectedStatus("3","$student->sex")); ?>>Khác</option>
                </select>
              </div>
              
              
              <?php if($errors->get('studentSex')): ?>
              <div class="form-inline cm-inline-form cm-error">
                <ul class="col-md-8 offset-md-4 cm-ul-error">
                  <?php $__currentLoopData = $errors->get('studentSex'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentSex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($studentSex); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
              
              
              <div class="form-inline cm-inline-form">
                <label for="studentBirthday" class="col-md-4 common-label-inline">Ngày sinh <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                <div class="col-md-8 px-0">
                  <input style="width: inherit;" id="studentBirthday" width="100%" class="form-control" name="studentBirthday" maxlength="10" required <?php if($errors->any()): ?> value="<?php echo e(old('studentBirthday')); ?>" <?php else: ?>  value="<?php echo e(convertToStringDate($student->birthday)); ?>"  <?php endif; ?>  >
                </div>
              </div>
              
              
              <?php if($errors->get('studentBirthday')): ?>
              <div class="form-inline cm-inline-form">
                <ul class="col-md-8 offset-md-4 cm-ul-error">
                  <?php $__currentLoopData = $errors->get('studentBirthday'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentBirthday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($studentBirthday); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
              
              
              <div class="form-inline cm-inline-form">
                <label for="studentAddress" class="col-md-4 common-label-inline">Địa chỉ:</label>
                <input type="text" class="form-control col-md-8" id="studentAddress" name="studentAddress" placeholder="Số nhà, tên đường" <?php if($errors->any()): ?> value="<?php echo e(old('studentAddress')); ?>" <?php else: ?>  value="<?php echo e($student->address); ?>"  <?php endif; ?>>
              </div>
              
              
              
              
              
              

            </div>
          </div>
        </div>
        
        
        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12">
          <div class="card">
            <div class="card-header">
              <b>Thông tin thêm</b>
            </div>
            <div class="card-body">
              
              <div class="form-inline cm-inline-form">
                <label for="studentShoolYear" class="col-md-4 common-label-inline">Niên khóa <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                <select id="studentShoolYear" class="form-control col-md-8" name="studentShoolYear" required>
                  <?php $__currentLoopData = $schoolYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($sy->id); ?>" <?php echo e(changeSelectedStatus("$sy->id","$student->school_year_id")); ?>><?php echo e($sy->course); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              
              <?php if($errors->get('studentShoolYear')): ?>
              <div class="form-inline cm-inline-form cm-error">
                <ul class="col-md-8 offset-md-4 cm-ul-error">
                  <?php $__currentLoopData = $errors->get('studentShoolYear'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentShoolYear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($studentShoolYear); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
              
              <div class="form-inline cm-inline-form">
                <label for="studentClass" class="col-md-4 common-label-inline">Lớp <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                <select id="studentClass" class="form-control col-md-8" name="studentClass" required>
                  <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($sy->id); ?>" <?php echo e(changeSelectedStatus("$sy->id","$student->class_id")); ?>><?php echo e($sy->class_name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
              
              <?php if($errors->get('studentClass')): ?>
              <div class="form-inline cm-inline-form cm-error">
                <ul class="col-md-8 offset-md-4 cm-ul-error">
                  <?php $__currentLoopData = $errors->get('studentClass'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $studentClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($studentClass); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
              
              <div class="form-inline cm-inline-form">
                <label for="studentPhone" class="col-md-4 common-label-inline">SDT:</label>
                <input type="number" class="form-control col-md-8" id="studentPhone" name="studentPhone" placeholder="Số điện thoại" maxlength="10" <?php if($errors->any()): ?> value="<?php echo e(old('studentPhone')); ?>" <?php else: ?>  value="<?php echo e($student->phone_no); ?>"  <?php endif; ?> >
              </div>
              
              <div class="form-inline cm-inline-form">
                <label for="isUnion" class="col-md-4 common-label-inline">Đoàn viên:</label>
                <input id="toggleisUnion" name="toggleisUnion" type="checkbox" data-width="120" data-height="20"  <?php if($student->is_youth_union_member == 1): ?> <?php echo e("checked value=1"); ?> <?php endif; ?>>
              </div>
              
              
              <div class="form-inline cm-inline-form show-off <?php if($errors->any()): ?> <?php echo e("show-off"); ?><?php endif; ?>">
                <label for="unionDate" class="col-md-4 common-label-inline">Ngày kết nạp:</label>
                <div class="col-md-8 px-0">
                  <input style="width: inherit;" id="unionDate" width="100%" class="form-control" name="unionDate" maxlength="10" <?php if($errors->any()): ?> value="<?php echo e(old('unionDate')); ?>" <?php else: ?> value="<?php echo e(convertToStringDate($student->date_on_union)); ?>" <?php endif; ?>>
                </div>
              </div>
              
              
              <?php if($errors->get('unionDate')): ?>
              <div class="form-inline cm-inline-form cm-error">
                <ul class="col-md-8 offset-md-4 cm-ul-error">
                  <?php $__currentLoopData = $errors->get('unionDate'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unionDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($unionDate); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
              
              
              <div class="form-inline cm-inline-form show-off <?php if($errors->any()): ?> <?php echo e("show-off"); ?><?php endif; ?>">
                <label for="unionPlace" class="col-md-4 common-label-inline">Nơi kết nạp:</label>
                <input type="text" class="form-control col-md-8" id="unionPlace" name="unionPlace" placeholder="Nơi kết nạp đoàn" value="">
              </div>
              
              <div class="form-inline cm-inline-form show-off <?php if($errors->any()): ?> <?php echo e("show-off"); ?><?php endif; ?>">
                <label for="toggleUnionFee" class="col-md-4 common-label-inline">Đoàn phí:</label>
                <input id="toggleUnionFee" name="toggleUnionFee" type="checkbox" data-width="120" data-height="20"   <?php if($student->is_payed_union_fee == 1): ?> <?php echo e("checked  value=1"); ?>  <?php endif; ?>>
              </div>
              
              
              <div class="form-inline cm-inline-form">
                <label for="isStudy" class="col-md-4 common-label-inline">Tình trạng học tập:</label>
                <select id="isStudy" class="form-control col-md-8" name="isStudy">
                  <option value="1" <?php if($student->is_study == 1): ?> <?php echo e("selected"); ?> <?php endif; ?>>Còn học</option>
                  <option value="2" <?php if($student->is_study == 2): ?> <?php echo e("selected"); ?> <?php endif; ?>>Đã tốt nghiệp</option>
                  <option value="3" <?php if($student->is_study == 3): ?> <?php echo e("selected"); ?> <?php endif; ?>>Bảo lưu</option>
                  <option value="4" <?php if($student->is_study == 4): ?> <?php echo e("selected"); ?> <?php endif; ?>>Đã nghỉ học</option>
                </select>
              </div>                            
              
              <?php if($errors->get('isStudy')): ?>
              <div class="form-inline cm-inline-form cm-error">
                <ul class="col-md-8 offset-md-4 cm-ul-error">
                  <?php $__currentLoopData = $errors->get('isStudy'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $isStudy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($isStudy); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>
              
            </div>
          </div> 
        </div>
      </div>
      <hr class="sidebar-divider">
      <div class="col-12 text-center">
        <button type="button" class="btn btn-warning cm-btn-form">Cancel</button>
        <button type="submit" class="btn btn-success cm-btn-form">Submit</button>
      </div>
    </form>
  </div>
  
  
  <div class="col-md-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb cm-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
        
      </ol>
    </nav>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
  $(document).on('submit','form#formEditStudent',function(){
    $(document).ajaxStart($.blockUI({ message: '<div class="spinner-grow text-primary" style="width: 3rem; height: 3rem;" role="status"><span class="sr-only">Loading...</span></div>', 
    css: {backgroundColor: 'transparent',border: 'none'} })).ajaxStop($.unblockUI);
  });
  // global variable
  var classes = <?php echo $class; ?>;
  <?php if(session('error')): ?>
      var error = "<?php echo e(session('error')); ?>";
      showNotify('error',error);
    <?php endif; ?>
  <?php if(session('success')): ?>
      var success = "<?php echo e(session('success')); ?>";
      showNotify('success',success);
  <?php endif; ?>
    </script>
    <script src="<?php echo e(asset('assets/js/admin/add_student.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/students/edit_student.blade.php */ ?>