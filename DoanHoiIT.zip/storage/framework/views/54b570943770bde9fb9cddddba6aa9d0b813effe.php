<footer id="footer">
    <!-- container -->
    <div class="container">
      <!-- row -->
      <div class="footer-bottom row">
        <div class="col-md-6 col-md-push-6">
          <ul class="footer-nav">
            <li><a href="<?php echo e(route('get_home_page')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('get_profile')); ?>">Information</a></li>
            <li><a href="<?php echo e(route('get_list_activity_user')); ?>">Activity</a></li>
          </ul>
        </div>
        <div class="col-md-6 col-md-pull-6">
          <div class="footer-copyright">
            Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made by HiKi
          </div>
        </div>
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </footer>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/user/layout/footer.blade.php */ ?>