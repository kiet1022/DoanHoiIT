<?php $__env->startSection('title'); ?>
Danh mục tin
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/vendor/datatables/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/datatables/css/select.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/admin/common.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/admin/common2.css')); ?>" rel="stylesheet" type="text/css">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<style>
  .no-js #loader {
    display: none;
  }

  .js #loader {
    display: block;
    position: absolute;
    left: 100px;
    top: 0;
  }

  .se-pre-con {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url("<?php echo e(asset('assets/img/Preloader_1.gif')); ?>") center no-repeat #fff;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<!-- PAGE HEADER -->
<div class="page-header">
  <div class="page-header-bg" style="background-image: url('<?php echo e(asset('assets/img/user/banner.jpg')); ?>');" data-stellar-background-ratio="0.5"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-offset-1 col-md-10 text-center">
        <h1 class="text-uppercase"></h1>
      </div>
    </div>
  </div>
</div>
<!-- /PAGE HEADER -->
<!-- SECTION -->
<div class="section">
  <!-- container -->
  <div class="container">
    <!-- row -->
    <div class="row">

      <div class="col-md-8">
        <form id="filterActivity" action="" method="get" class="col-md-12">
          <div class="col-md-6">
            <select name="activity-type" class="form-control">
              <option value="0">Tất cả chương trình</option>
              <option value="1"> Chương trình đã đăng kí</option>
            </select>
          </div>
        </form>

        <!-- activity  -->
        <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class=" activity-detail col-md-12 rounded">
          <div class="activity activity-row">
            <div class="activity-body">
              <h3 class="activity-title col-md-10"><a class="btnView" data-id="<?php echo e($list->id); ?>" data-toggle="modal"><?php echo e($list->name); ?></a></h3>
              <div class="col-md-2"><a class="btnView" data-id="<?php echo e($list->id); ?>" data-toggle="modal"> <i class="fas fa-eye cm-label text-primary"></i> </a></div>
              <p class="col-md-12">Thời gian đăng kí: <span><?php echo e(date('d/m/Y',strtotime($list->start_regis_date))); ?></span> - <span><?php echo e(date('d/m/Y',strtotime($list->end_regis_date))); ?></span> </p>
              <p class="col-md-9"> Số lượng đăng ký: <span>10/<?php echo e($list->max_regis_num); ?></span></p>

              <?php if($list->end_regis_date < Carbon\Carbon::today()): ?> 
                <p class="col-md-3 time-expired">Hết hạn đăng kí</p>
              <?php else: ?>
                <?php if(count($registActivity)==null): ?>
                <div class="col-md-3"><button class="btn btnRegist" id="activity_<?php echo e($list->id); ?>" data-id="<?php echo e($list->id); ?>">Đăng kí</button></div>
               
                <?php else: ?>
                  <?php $__currentLoopData = $registActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listRes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($listRes->activity_id ===$list->id): ?>
                      <p class="col-md-3 time-expired">Đã đăng kí</p>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- /activity -->
      </div>
      <?php echo $__env->make('user.layout.sideBarRight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- /row -->

  </div>

  <!-- view activity Modal -->
  <div class="modal animated jackInTheBox" id="formViewActivity" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true"></div>
  <!-- /container -->
</div>
<!-- /SECTION -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/common.js')); ?>"></script>

<script>
  var BASE_URL = "<?php echo e(asset('/activity/')); ?>"
</script>
<script type="text/javascript">
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });
  $('.btnView').on('click', function() {
    var id = $(this).data('id');
    $.ajax({
      url: BASE_URL + "/view.php",
      method: 'POST',
      data: {
        id: id,
      }
    }).done(function(data) {
      console.log(data);
      $('#formViewActivity').html(data);
      $('#formViewActivity').modal('show');
    }).fail(function(xhr, status, error) {
      console.log(this.url);
      console.log(status);
      console.log(error);
    });
  });
  $('.btnRegist').on('click', function() {
    var id = $(this).data('id');
    var buttonId = "#activity_" + id;
    $.ajax({
      url: BASE_URL + "/registActivity.php",
      method: 'POST',
      data: {
        id: id,
      }
    }).done(function(data) {
      if (data.result == "OK") {
        alert('Đăng kí hoạt động thành công');
        $(buttonId).attr("disabled", true);
      } else {
        alert('Đăng kí hoạt động thất bại')
      }
      // console.log(data);
      // $('#formViewActivity').html(data);
      // $('#formViewActivity').modal('show');
    }).fail(function(xhr, status, error) {
      alert('Đăng kí hoạt động thất bại')
      console.log(this.url);
      console.log(status);
      console.log(error);
    });
  });
   $('select').change(function () {
     document.getElementById('filterActivity').submit();
 });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/user/activity/index.blade.php */ ?>