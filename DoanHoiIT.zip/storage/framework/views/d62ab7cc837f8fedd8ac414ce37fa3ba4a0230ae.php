<?php /* D:\xampp\htdocs\DoanHoi\resources\views/admin/trash/data_table_trash.blade.php */ ?>
<?php if($type === config('constants.TRASH_STUDENTS')): ?>
<thead style="background: #f8f9fc">
    <tr>
        <th></th>
        <th>MSSV</th>
        <th>Họ Tên</th>
        <th>Khóa</th>
        <th>Lớp</th>
        <th>Giới tính</th>
        <th>Ngày sinh</th>
        <th>Tình trạng</th>
        <td>Ngày xóa</td></td>
        
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $studentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="">
        <td><input type="hidden" value="<?php echo e($list->student_id); ?>"></td>
        <td><?php echo e($list->student_id); ?></td>
        <td><?php echo e($list->name); ?></td>
        <td><?php echo e($list->schoolYear->course); ?></td>
        <td><?php echo e($list->class->class_name); ?></td>
        <td><?php echo changeGenderForList($list->sex); ?></td>
        <td><?php echo e(date('d/m/Y',strtotime($list->birthday))); ?></td>
        <td class="text-center"><?php echo changeStudyStatus($list->is_study); ?></td>
        <td><?php echo e(date('d/m/Y',strtotime($list->deleted_at))); ?></td>
        
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php elseif($type === config('constants.TRASH_ACTIVITIES')): ?>
<thead style="background: #f8f9fc">
    <tr>
        <th></th>
        <th>Mã chương trình</th>
        <th>Tên chương trình</th>
        <th>Thời gian diễn ra</th>
        <th>Sinh viên đứng chính</th>
        <th>Trạng thái</th>
        <th>Ngày xóa</th>
        
        
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="">
        <td></td>
        <td><?php echo e($activity->id); ?></td>
        <td><?php echo e($activity->name); ?></td>
        <td><?php echo e(date('d/m/Y',strtotime($activity->start_date))); ?> - <?php echo e(date('d/m/Y',strtotime($activity->end_date))); ?></td>
        <td><?php echo e($activity->leadBy->name); ?> - <?php echo e($activity->leadBy->student_id); ?></td>
        <td class="text-center"><?php echo changeActivityStatus($activity->start_date, $activity->end_date); ?></td>
        <td><?php echo e(date('d/m/Y',strtotime($activity->deleted_at))); ?></td>
        
        
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
<?php endif; ?>