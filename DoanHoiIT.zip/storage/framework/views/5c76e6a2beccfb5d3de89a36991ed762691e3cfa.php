<?php /* D:\xampp\htdocs\DoanHoi\resources\views/admin/log/logs.blade.php */ ?>
<?php $__env->startSection('title'); ?>
Lịch sử hoạt động
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/vendor/datatables/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/datatables/css/select.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/admin/common.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/admin/common2.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/datepicker-master/dist/datepicker.css')); ?>">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col page-title-header">
      <h4>Lịch sử hoạt động</h4>
    </div>
  </div>
  <div class="row">
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <form action="<?php echo e(route('filter_logs')); ?>" method="POST" class="col-md-12">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          
          <div class="form-inline cm-inline-form col-md-3 offset-md-3">
            <label for="beginDate" class="col-md-4 common-label-inline">Từ ngày:</label>
            <div class="col-md-8 px-0">
            <input style="width: inherit;" id="beginDate" width="100%" class="form-control" name="beginDate" maxlength="10" value="<?php echo e(old('beginDate')); ?>">
            </div>
          </div>
          
          
          <div class="form-inline cm-inline-form col-md-3">
            <label for="endDate" class="col-md-4 common-label-inline">Đến ngày:</label>
            <div class="col-md-8 px-0">
              <input style="width: inherit;" id="endDate" width="100%" class="form-control" name="endDate" maxlength="10" value="<?php echo e(old('endDate')); ?>">
            </div>
          </div>
          
        </div>
        <div class="form-group col-md-2 offset-md-10">
          <button type="submit" class="btn btn-primary right"><i class="fas fa-filter"></i> Lọc</button>
        </div>
      </form>
    </div>
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <!-- Begin Page Content -->      
      <!-- DataTales Example -->
      <div class="card mb-4">
        
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
              <thead style="background: #f8f9fc">
                <tr>
                  <th>MSSV</th>
                  <th>Họ Tên</th>
                  <th>Quyền</th>
                  <th>Hành động</th>
                  <th>Dữ liệu cũ</th>
                  <th>Dữ liệu mới</th>
                  <th>Thời gian thực hiện</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                  <td><?php echo e($log->student_id); ?></td>
                  <td><?php echo e($log->student_name); ?></td>
                  <td><?php echo e($log->role); ?></td>
                  <td><?php echo e($log->action); ?></td>
                  <td><?php echo $log->old_data; ?></td>
                  <td><?php echo $log->new_data; ?></td>
                  <td><?php echo e(date('d/m/Y H:i:s',strtotime($log->time_id))); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <div class="col-md-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb cm-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
        
      </ol>
    </nav>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <!-- Page level plugins -->
  <script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.select.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/datepicker-master/dist/datepicker.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/datepicker-master/i18n/datepicker.vi-VN.js')); ?>"></script>
  
  <script>
    var classes = <?php echo $class; ?>;
    var BASE_URL = "<?php echo e(asset('admin/student/')); ?>"
  </script>
  <!-- Page level custom scripts -->
  <script src="<?php echo e(asset('assets/js/admin/logs.js')); ?>"></script>
  
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>