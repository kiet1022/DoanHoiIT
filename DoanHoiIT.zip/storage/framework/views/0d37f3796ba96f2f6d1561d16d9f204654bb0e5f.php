<?php /* D:\xampp\htdocs\DoanHoi\resources\views/admin/activity/list_activity.blade.php */ ?>
<?php $__env->startSection('title'); ?>
Danh sách chương trình
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/vendor/datatables/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/datatables/css/select.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/admin/common.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/admin/common2.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/admin/activity/list_activity.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/datepicker-master/dist/datepicker.css')); ?>">
<style>
  /* Bootstrap4 Dialog */
  .bootstrap-dialog-header {
    width: 100%;
  }
  
  .bootstrap-dialog-footer-buttons button {
    margin-left: 5px;
    margin-right: 5px;
  }
</style>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col page-title-header">
      <h4>Danh sách chương trình</h4>
    </div>
  </div>
  <div class="row">
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <form action="<?php echo e(route('filter_activity')); ?>" method="POST" class="col-md-12" id="filterActivity">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          
          <div class="form-inline cm-inline-form col-md-3 offset-md-3">
            <label for="year" class="col-md-3 common-label-inline">Năm học:</label>
            <div class="col-md-8 col-sm-8 col-xs-8 px-0">
              <select name="year" id="year" class="form-control" style="width:150px;">
                <option value="">Chọn năm học</option>
                <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($y->name); ?>"><?php echo e($y->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          
          
          <div class="form-inline cm-inline-form col-md-3">
            <label for="semester" class="col-md-3 common-label-inline">Học kỳ:</label>
            <div class="col-md-8 col-sm-8 col-xs-8 px-0">
              <select name="semester" id="semester" class="form-control" style="width:150px;">
                <option value="">Chọn học kỳ</option>
                <option value="1">Kỳ 1</option>
                <option value="2">Kỳ 2</option>
              </select>
            </div>
          </div>
          
        </div>
        <div class="form-group col-md-2 offset-md-10">
          <button type="submit" class="btn btn-primary right"><i class="fas fa-filter"></i> Lọc</button>
        </div>
      </form>
    </div>
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <!-- Begin Page Content -->      
      <!-- DataTales Example -->
      <div class="card mb-4">
        
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
              <thead style="background: #f8f9fc">
                <tr>
                  <th></th>
                  <th>Mã chương trình</th>
                  <th>Tên chương trình</th>
                  <th>Thời gian diễn ra</th>
                  <th>Sinh viên đứng chính</th>
                  <th>Trạng thái</th>
                  <th>Số lượng đăng ký</th>
                  <th>Chương trình</th>
                  <th>Dự trù</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                  <td></td>
                  <td><?php echo e($activity->id); ?></td>
                  <td><?php echo e($activity->name); ?></td>
                  <td><?php echo e(date('d/m/Y',strtotime($activity->start_date))); ?> - <?php echo e(date('d/m/Y',strtotime($activity->end_date))); ?></td>
                  <td><?php echo e($activity->leadBy->name); ?> - <?php echo e($activity->leadBy->student_id); ?></td>
                  <td class="text-center"><?php echo changeActivityStatus($activity->start_date, $activity->end_date); ?></td>
                  <td><?php echo "0"; ?></td>
                  <td class="text-center">
                      <a class="cm-label text-info detailToggle" data-id="<?php echo e($activity->id); ?>" data-toggle="modal"><i class="fas fa-list" title="Chi tiết"></i></a>
                      <a href="<?php echo e(route('get_edit_activity',['id'=>$activity->id])); ?>"><i class="fas fa-edit cm-label text-primary" title="Chỉnh sửa"></i></a>
                    </td>
                  <td class="text-center">
                    <?php if($activity->fund == null): ?>
                    <a href="<?php echo e(route('get_add_activity_funding',['id'=>$activity->id])); ?>" class="btn btn-info btn-sm">Tạo dự trù</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('get_edit_activity_funding',['id'=>$activity->fund->id])); ?>" class="btn btn-primary btn-sm" data-id="<?php echo e($activity->id); ?>"><i class="fas fa-edit cm-label text-white" title="Chỉnh sửa dự trù"></i> Sửa</a>
                    <a href="#" class="btn btn-danger btn-sm delete-fund-detail" data-content="<?php echo e($activity); ?>"><i class="fas fa-trash-alt cm-label text-white" title="Xóa dự trù"></i> Xóa</a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <a class="btn btn-success" href="<?php echo e(route('get_add_activity')); ?>"><i class="fas fa-plus-circle"></i> Thêm chương trình</a>
      <button onclick="deleteActivity()" class="btn" id="deleteUser" style="background-color: #D98880; color: #fff"><i class="fas fa-minus-circle"></i> Xóa chương trình</button>
    </div>
  </div>
  
  <div class="col-md-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb cm-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
        
      </ol>
    </nav>
  </div>
  <!-- Modal -->
  <div class="modal animated jackInTheBox" id="activityDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <!-- Page level plugins -->
  <script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.select.min.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/datepicker-master/dist/datepicker.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/vendor/datepicker-master/i18n/datepicker.vi-VN.js')); ?>"></script>
  <script>
    var BASE_URL = "<?php echo e(asset('admin/activities/')); ?>";
    var BASE_FUNDING_URL = "<?php echo e(asset('admin/activities/funding')); ?>";
  </script>
  <script src="<?php echo e(asset('assets/js/admin/activity/list_activity.js')); ?>"></script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>