<?php $__env->startSection('title'); ?>
Chương trình đào tạo
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="row">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Quản lý niên khóa</li>
          </ol>
        </nav>
      </div>
    <div class="row">
        <div class="col page-title-header">
            <h4>Niên khóa</h4>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
                    <!-- Begin Page Content -->      
                <!-- DataTales Example -->
                <div class="card mb-4">
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead style="background: #f8f9fc">
                          <tr>
                            <th></th>
                            <th style="display: none;"></th>
                            <th>Niên khóa</th>
                            <th>Khóa</th>
                            <th>Thời gian đào tạo</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $schoolYear; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td></td>
                            <td style="display: none;"><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->name); ?></td>
                            <td> <?php echo e($list->course); ?></td>
                            <td><?php if($list->type==1): ?><?php echo e("2 năm"); ?> <?php elseif($list->type==2): ?><?php echo e("4 năm"); ?> <?php endif; ?></td>
                            <td><i class="far fa-edit"></i> 
                                <!-- <a href="<?php echo e(route('get_edit_program',['id'=>$list->id])); ?>">Sửa</a> -->
                                <a class="editToggle" data-id="<?php echo e($list->id); ?>"  data-toggle="modal" href="">Sửa</a>
                                
                            </td>
                            </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
                <!-- /.container-fluid -->
                <!-- <a class="btn btn-success" href="<?php echo e(route('get_add_program')); ?>"><i class="fas fa-plus-circle"></i> Thêm tin</a> -->
                <a class="btn btn-success" id="addProgram"><i class="fas fa-plus-circle"></i> Thêm chương trình đào tạo</a>
                <button onclick="deleteProgram()" class="btn delete_all" style="background-color: #D98880; color: #fff"><i class="fas fa-minus-circle"></i> Xóa</button> 
        </div>
    </div>
    <!-- add academic Modal -->
<div class="modal animated jackInTheBox" id="formAdd" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
</div>
 <!-- edit academic Modal -->
<div class="modal animated jackInTheBox" id="formEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
 <!-- Page level plugins -->
 <!-- Page level custom scripts -->
 
<script>
  var BASE_URL = "<?php echo e(asset('admin/school-year/education-program/')); ?>"
</script>
<script src="<?php echo e(asset('assets/js/admin/program.js')); ?>"></script>
<script>
//paste this code under the head tag or in a separate js file.
//Wait for window load
// $(window).load(function() {
    // 	// Animate loader off screen
    // 	$(".se-pre-con").fadeOut("slow");
    // });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/academic/academic_list.blade.php */ ?>