<?php
    $i=0;
?>
<table>
    <thead>
    <tr style="background-color:red;">
        <th>STT</th>
        <th>MSSV</th>
        <th>Họ tên</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($i++); ?></td>
            <td><?php echo e($detail->student_id); ?></td>
            <td>
                <?php if(!is_null($detail->ofStudent)): ?>
                <?php echo e($detail->ofStudent->name); ?>

                <?php else: ?>
                <?php echo e("Sinh viên không xác định"); ?>

                <?php endif; ?>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/excel_export_template/marks_template.blade.php */ ?>