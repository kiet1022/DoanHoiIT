<?php $__env->startSection('title'); ?>
<?php echo e("Đổi mật khẩu"); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?>
<div class="container">
	<ol class="breadcrumb" style="background-color: #ffffff; margin-bottom: 0px; border-left: 5px solid #4e73df;">
		<li><a href="<?php echo e(route('get_home_page')); ?>" class="text-info">Trang chủ</a></li>
    <li>Thông tin cá nhân</li>
    <li>Đổi mật khẩu</li>
	</ol>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-9" style="background: white; padding-top: 30px;">
	<?php if(count($errors)>0): ?>
	<div class="alert alert-warning alert-dismissible show" role="alert">
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php echo e($err); ?><br>
		<button type="button" class="close" data-dismiss="alert" aria-label="Close">
			<span aria-hidden="true">&times;</span>
		</button>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
	<?php endif; ?>
	
	<div class="col-md-10 col-md-offset-1" style="min-height: 437px;">
		<form action="<?php echo e(route('post_user_change_pass')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<div class="form-group">
					<label for="oldpass">Nhập mật khẩu cũ:</label>
					<input type="password" class="form-control" id="oldpass" placeholder="Nhập mật khẩu cũ" name="oldpass" required>
			</div>

			<div class="form-group">
				<label for="newpass">Nhập mật khẩu mới:</label>
					<input type="password" class="form-control" id="newpass" placeholder="Nhập mật khẩu mới" name="newpass" required>
      </div>
      
      <div class="form-group">
				<label for="renewpass">Nhập lại mật khẩu mới:</label>
					<input type="password" class="form-control input" id="renewpass" placeholder="Nhập lại mật khẩu mới" name="renewpass" required>
					<span style="display: none" id="notmatch"><small style="color:red">Mật khẩu mới chưa trùng khớp</small></span>
			</div>

			<div class="form-group text-center">  
					<button id="btnsubmit" type="submit" class="btn" style="width: 150px;background: #4e73df; color:white">Lưu</button>
			</div>
		</form>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
	$('form').on('submit', function(){
		blockUI(true);
	})

	<?php if(session('error')): ?>
    var error = "<?php echo e(session('error')); ?>";
    showNotify('error',error);
    <?php endif; ?>
    <?php if(session('success')): ?>
    var success = "<?php echo e(session('success')); ?>";
    console.log(success)
    showNotify('success',success);
    <?php endif; ?>

    $('form').on('submit', function(){
      blockUI(true);
    });

	// Check if new password not match
	$('.input').on('keyup', function(e){
		var newpass = $('#newpass').val();
		if(newpass != e.target.value){
			$(this).css({"outline": "none !important","border":"1px solid red","box-shadow": "0 0 10px #719ECE"});
			$('#btnsubmit').attr("disabled",true);
			$('#notmatch').css({"display":"block"});
		} else if(newpass === e.target.value){
			$(this).css({"outline": "none !important","border":"1px solid green","box-shadow": "0 0 10px #719ECE"});
			$('#btnsubmit').attr("disabled",false);
			$('#notmatch').css({"display":"none"});
		}
	});
</script>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layout.userindex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/change_pass.blade.php */ ?>