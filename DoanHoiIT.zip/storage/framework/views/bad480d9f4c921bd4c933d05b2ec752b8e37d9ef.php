<?php $__env->startSection('title', 'Trang chủ'); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('pages/css/homepagenews.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="news">
	<div class="section" style="padding-top: 0">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				
				<div class="col-md-7">
					<div class="row" style="display: flex; flex-wrap: wrap;">
						<!-- Tin lớn -->
						<div class="col-md-12">
							<div class="post post-thumb">
								<a class="post-img" href=""><img style="width: 750px; height: 410px;" src="<?php echo e(asset('images/news/'.$newNews[0]->image)); ?>" alt="Lỗi"></a>
								<div class="post-body">
									<div class="post-meta">
										<a class="post-category <?php echo e(changeCatColor($newNews[0]->ofType->id)); ?>" href="category.html"><?php echo e($newNews[0]->ofType->name); ?></a>
										<span class="post-date">Ngày đăng: <?php echo e(date('d/m/Y',strtotime($newNews[0]->created_at))); ?></span>
									</div>
									<h3 class="post-title"><a href="<?php echo e(route('get_new_detail',['id'=>$newNews[0]->id])); ?>"><?php echo e($newNews[0]->title); ?></a></h3>
								</div>
							</div>
						</div>
						
						
						<div class="col-md-12 text-center" style="margin-bottom: 15px">
							<div class="col-md-4 badge-header-primary">
								<h4 style="color: white; margin: 5px">Hôm nay có gì mới</h4>
							</div>
							<div class="col-md-12" style="border-bottom: 2px solid #4e73df;">
							</div>
						</div>
						<!-- Các tin con -->
						<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-6">
							<div class="post">
								<a class="post-img" href=""><img style="width: 360px; height: 197px;" src="<?php echo e(asset('images/news/'.$new->image)); ?>" alt="Lỗi"></a>
								<div class="post-body">
									<div class="post-meta">
										<a class="post-category <?php echo e(changeCatColor($new->ofType->id)); ?>" href="category.html"><?php echo e($new->ofType->name); ?></a>
										<br>
										<span class="post-date">Ngày đăng: <?php echo e(date('d/m/Y',strtotime($new->created_at))); ?></span>
									</div>
									<h3 class="post-title"><a href="<?php echo e(route('get_new_detail',['id'=>$new->id])); ?>"><?php echo e($new->title); ?></a></h3>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
						
						<div class="col-md-12 text-center" style="margin-bottom: 15px">
							<div class="col-md-5 badge-header-success">
								<h4 style="color: white; margin: 5px">Hoạt động Đoàn - Hội khoa</h4>
							</div>
							<div class="col-md-12" style="border-bottom: 2px solid #1cc88a;">
							</div>
						</div>
						<!-- Các tin con -->
						<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-6">
							<div class="post">
								<a class="post-img" href=""><img style="width: 360px; height: 197px;" src="<?php echo e(asset('images/news/'.$new->image)); ?>" alt="Lỗi"></a>
								<div class="post-body">
									<div class="post-meta">
										<a class="post-category <?php echo e(changeCatColor($new->ofType->id)); ?>" href="category.html"><?php echo e($new->ofType->name); ?></a>
										<br>
										<span class="post-date">Ngày đăng: <?php echo e(date('d/m/Y',strtotime($new->created_at))); ?></span>
									</div>
									<h3 class="post-title"><a href="<?php echo e(route('get_new_detail',['id'=>$new->id])); ?>"><?php echo e($new->title); ?></a></h3>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				
				
				<div class="col-md-5">
					<div class="col-md-12 text-center" style="margin-bottom: 15px; padding: 0">
						<div class="col-md-6 badge-header-warning">
							<h4 style="color: white; margin: 5px">Chương trình trong tháng</h4>
						</div>
						<div class="col-md-12" style="border-bottom: 2px solid #f4b619 ;">
						</div>
					</div>
					<div class="aside-widget">
						<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="post post-widget">
							<a class="post-img" href="<?php echo e(route('user_get_activity_detail',['id'=>$act->id])); ?>">
								<?php if($act->image): ?>
								<img style="width: 90px; height: 49px;" src="<?php echo e(asset('assets/fileupload/activities/images/'.$act->image)); ?>" alt="Lỗi">
								<?php else: ?>
								<img style="width: 90px; height: 49px;" src="<?php echo e(asset('assets/img/faculty_banner.png')); ?>" alt="Lỗi">
								<?php endif; ?>
								
							</a>
							<div class="post-body">
								<h3 class="post-title"><a href="<?php echo e(route('user_get_activity_detail',['id'=>$act->id])); ?>"><?php echo e($act->name); ?></a></h3>
								<span class="post-date">Thời gian: <?php echo e(date('d/m/Y',strtotime($act->start_date))); ?> - <?php echo e(date('d/m/Y',strtotime($act->end_date))); ?></span>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					
					
					<!-- catagories -->
					<div class="aside-widget">
						<div class="col-md-12 text-center" style="margin-bottom: 15px; padding: 0">
							<div class="col-md-6 badge-header-danger">
								<h4 style="color: white; margin: 5px">Danh mục tin tức</h4>
							</div>
							<div class="col-md-12" style="border-bottom: 2px solid #e74a3b ;">
							</div>
						</div>
						
						<div class="category-widget">
							<ul>
								<?php $__currentLoopData = $newsType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><a href="#" class="<?php echo e(changeCatColor($nt->id)); ?>"><?php echo e($nt->name); ?><span><?php echo e(count($nt->news)); ?></span></a></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>
					<!-- /catagories -->
					
					<!-- catagories -->
					<div class="aside-widget">
						<div class="col-md-12 text-center" style="margin-bottom: 15px; padding: 0">
							<div class="col-md-6 badge-header-info">
								<h4 style="color: white; margin: 5px">Kết nối với chúng tôi</h4>
							</div>
							<div class="col-md-12" style="border-bottom: 2px solid #36b9cc ;">
							</div>
						</div>
						
						<div class="category-widget col-md-12" style="display: flex; flex-wrap: wrap;">
							<div class="col-md-4 socialite facebook-background">
								<a href="https://www.facebook.com/DoanHoiITUTE/" class="text-white" target="_blank">
										<i class="fa fa-facebook"></i>
										<span>
											3K
											<br>
											Người theo dõi
										</span>
								</a>
							</div>

							<div class="col-md-4 socialite google-background">
									<a href="mailto:doaihoiitspkt@gmail.com" class="text-white" target="_blank">
											<i class="fa fa-google-plus"></i>
											<span>
													Liên hệ
												<br>
												Thư điện tử
											</span>
									</a>
								</div>

								<div class="col-md-4 socialite faculty-background">
										<a href="http://fit.hcmute.edu.vn/" class="text-white" target="_blank">
												<i class="fa fa-globe"></i>
												<span>
													Truy cập
													<br>
													Website
												</span>
										</a>
									</div>
						</div>
					</div>
					<!-- /catagories -->
				</div>
			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/index.blade.php */ ?>