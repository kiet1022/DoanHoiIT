<footer class="sticky-footer bg-white">
    <div class="container my-auto">
      <div class="copyright text-center my-auto">
        <span> Copyright &copy;2019 Đoàn TN - Hội SV Khoa Công nghệ Thông Tin ĐH SPKT TP.HCM </span>
      </div>
    </div>
  </footer>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/layout/footer.blade.php */ ?>