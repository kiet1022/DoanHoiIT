<?php /* D:\xampp\htdocs\SVN\resources\views/admin/execComm/exec_comm_chart.blade.php */ ?>
<?php $__env->startSection('title'); ?>
Sơ đồ Ban chấp hành
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/vendor/datatables/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/datatables/css/select.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/admin/common.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/admin/common2.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/admin/execComm/exec_comm_chart.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col page-title-header">
                <h4>Sơ đồ <?php if($commType == "0"): ?>Ban chấp hành Đoàn Khoa <?php elseif($commType == "1"): ?>Ban chấp hành Liên chi hội <?php endif; ?></h4>
        </div>
    </div>
    <div class="row">

      <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
            <div style="width:100%; height:700px;" id="orgchart"></div>
            <a href="<?php echo e(route('get_ec_list')); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a>
            <span> | </span>
            <?php if($commType == "1"): ?>
            <a class="cm-breadcrumb-a" href="<?php echo e(route('get_ec_chart',["type"=>"0"])); ?>">Sơ đồ BCH Đoàn Khoa <i class="fas fa-arrow-circle-right"></i></a>
            <?php elseif($commType == "0"): ?>
            <a class="cm-breadcrumb-a" href="<?php echo e(route('get_ec_chart',["type"=>"1"])); ?>">Sơ đồ BCH Liên chi hội <i class="fas fa-arrow-circle-right"></i></a>
            <?php endif; ?>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
 <!-- Page level plugins -->
<script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.select.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/orgchart.js')); ?>"></script>
 <!-- Page level custom scripts -->
 
<script>
    $( document ).ready(function(){
        $('#dataTable').DataTable({
        columnDefs: [ {
            orderable: false,
            className: 'select-checkbox',
            targets:   0
        } ],
        select: {
            style:    'os',
            selector: 'td:first-child'
        },
        order: [[ 1, 'asc' ]],
        "pageLength": 25,
        "language": {
            "lengthMenu": "Hiển thị _MENU_ dòng trên trang",
            "zeroRecords": "Không có dữ liệu.",
            "info": "Trang _PAGE_/_PAGES_",
            "infoEmpty": "Không tồn tại dữ liệu.",
            "infoFiltered": "(đã lọc từ _MAX_ dòng)",
            "search": "Tìm kiếm"
        }
    });
        });
    </script>
    
    <script>
        var bithuArr = [];
        var phoBithuArr = [];
        var uvBCHArr = [];

        /**
        * Render Chart
        */

        // BCH Đoàn
        <?php if($commType == "0"): ?>
            <?php $__currentLoopData = $execComm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if("<?php echo $comm->level; ?>" == "1"){
                    bithuArr.push({
                        "name":"<?php echo $comm->ofStudent->name; ?>",
                        "MSSV":"<?php echo $comm->ofStudent->student_id; ?>",
                        "level":"Bí thư",
                        "phone": "<?php echo $comm->ofStudent->phone_no; ?>",
                        "image": "<?php echo e($comm->ofStudent->image); ?>"
                    });
                } else if ("<?php echo $comm->level; ?>" == "2"){
                    phoBithuArr.push({
                        "name":"<?php echo $comm->ofStudent->name; ?>",
                        "MSSV":"<?php echo $comm->ofStudent->student_id; ?>",
                        "level":"Phó Bí thư",
                        "phone": "<?php echo $comm->ofStudent->phone_no; ?>",
                        "image": "<?php echo e($comm->ofStudent->image); ?>"
                });
                } else if("<?php echo $comm->level; ?>" == "3"){
                    phoBithuArr.push({
                        "name":"<?php echo $comm->ofStudent->name; ?>",
                        "MSSV":"<?php echo $comm->ofStudent->student_id; ?>",
                        "level":"Phó Bí thư (LCH Trưởng)",
                        "phone": "<?php echo $comm->ofStudent->phone_no; ?>",
                        "image": "<?php echo e($comm->ofStudent->image); ?>"
                });
                }else {
                    uvBCHArr.push({
                        "name":"<?php echo $comm->ofStudent->name; ?>",
                        "MSSV":"<?php echo $comm->ofStudent->student_id; ?>",
                        "level":"Ủy viên BCH",
                        "phone": "<?php echo $comm->ofStudent->phone_no; ?>",
                        "image": "<?php echo e($comm->ofStudent->image); ?>"
                });
                }
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif($commType == "1"): ?>
        // BCH LCH
            <?php $__currentLoopData = $execComm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                if("<?php echo $comm->level; ?>" == "1"){
                    bithuArr.push({
                        "name":"<?php echo $comm->ofStudent->name; ?>",
                        "MSSV":"<?php echo $comm->ofStudent->student_id; ?>",
                        "level":"LCH Trưởng",
                        "phone": "<?php echo $comm->ofStudent->phone_no; ?>",
                        "image": "<?php echo e($comm->ofStudent->image); ?>"
                });
                } else if ("<?php echo $comm->level; ?>" == "2"){
                    phoBithuArr.push({
                        "name":"<?php echo $comm->ofStudent->name; ?>",
                        "MSSV":"<?php echo $comm->ofStudent->student_id; ?>",
                        "level":"LCH Phó",
                        "phone": "<?php echo $comm->ofStudent->phone_no; ?>",
                        "image": "<?php echo e($comm->ofStudent->image); ?>"
                });
                } else {
                    uvBCHArr.push({
                        "name":"<?php echo $comm->ofStudent->name; ?>",
                        "MSSV":"<?php echo $comm->ofStudent->student_id; ?>",
                        "level":"Ủy viên BCH",
                        "phone": "<?php echo $comm->ofStudent->phone_no; ?>",
                        "image": "<?php echo e($comm->ofStudent->image); ?>"
                });
                }
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    
    // init chart
    var chart = new OrgChart(document.getElementById("orgchart"), {
            nodeBinding: {
                field_0: "name",
                field_1: "title",
                field_2: "mssv",
                field_3: "phone",
                img_0: "img"
            },
            template: "rony",
            toolbar: true,
        layout: BALKANGraph.tree,
        scaleInitial: BALKANGraph.match.boundary,
        align: BALKANGraph.ORIENTATION,
        menu: {
            pdf: { text: "Export PDF" },
            png: { text: "Export PNG" },
            svg: { text: "Export SVG" },
            csv: { text: "Export CSV" }
        },
        });

    // pass data to nodes
        var j = 1;
        var BASE_IMAGE_URL = "<?php echo e(asset('assets/img/students/')); ?>";
        var IMAGE_NOT_AVAILABLE = "<?php echo e(asset('assets/img/image-not-available.png')); ?>";

        function checkExistImage(img){
            var result;
            if(img === "null"){
                result = IMAGE_NOT_AVAILABLE;
            }else {
                result = BASE_IMAGE_URL+"/"+img;
            }
            return result;
        }
        for(var i = 0; i < bithuArr.length; i++){
            var img = checkExistImage(bithuArr[i].image);
            chart.add({ 
              id: j, 
              name: bithuArr[0].name, 
              img: img,
              title: bithuArr[i].level, 
              phone: bithuArr[i].phone,
              mssv: bithuArr[i].MSSV});
            j++;
        }
        for(var i = 0; i < phoBithuArr.length; i++){
            var img = checkExistImage(phoBithuArr[i].image);
            chart.add({ 
              id: j,
              pid: 1, 
              tags: ["assistant"], 
              name: phoBithuArr[i].name, 
              img: img, 
              title: phoBithuArr[i].level, 
              phone: phoBithuArr[i].phone,
              mssv: phoBithuArr[i].MSSV})
            j++;
        }
        for(var i = 0; i < uvBCHArr.length; i++){
            var img = checkExistImage(uvBCHArr[i].image);
            chart.add({ 
              id: j, 
              pid: 1, 
              name: uvBCHArr[i].name,
              img: img,
              title: uvBCHArr[i].level, 
              phone: uvBCHArr[i].phone,
              mssv: uvBCHArr[i].MSSV});
            j++;
        }
        
    // assign tag name for node
        for (var i = 0; i < chart.config.nodes.length; i++) {
        var node = chart.config.nodes[i];
        switch (node.title) {
            case "Bí thư":
            case "LCH Trưởng":
                node.tags = ["BT"];
                break;
            case "Phó Bí thư":
            case "LCH Phó":
                node.tags = ["assistant"];
                break;
            case "Ủy viên BCH":
                node.tags = ["UV"];
                break;
        }
    // draw chart
        chart.draw(BALKANGraph.action.init);
    }
            
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>