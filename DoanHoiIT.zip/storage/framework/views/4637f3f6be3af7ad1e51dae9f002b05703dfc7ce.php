<?php $__env->startSection('title'); ?>
Danh sách chương trình
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/admin/activity/list_activity.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="row">
        <nav aria-label="breadcrumb">
          <ol class="breadcrumb">
            <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
            <li class="breadcrumb-item"><i class="fas fa-angle-right"></i> Quản lý chương trình</li>
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Danh sách chương trình</li>
          </ol>
        </nav>
    </div>
  <div class="row">
    <div class="col page-title-header">
      <h4>Danh sách chương trình</h4>
    </div>
  </div>
  <div class="row">
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <form action="<?php echo e(route('filter_activity')); ?>" method="POST" class="col-md-12" id="filterActivity">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          
          <div class="form-group col-md-4 offset-md-2">
            <label for="year" class="col-12 common-label-inline">Năm học:</label>
            <div class="col-8 px-0">
              <select name="year" id="year" class="form-control">
                <option value="">Chọn năm học</option>
                <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($y->name); ?>" 
                  <?php if(old('year')): ?>
                    <?php echo e(changeSelectedStatus($y->name, old('year'))); ?>

                  <?php endif; ?>>
                <?php echo e($y->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          
          
          <div class="form-group col-md-4">
            <label for="semester" class="col-12 common-label-inline">Học kỳ:</label>
            <div class="col-8 px-0">
              <select name="semester" id="semester" class="form-control">
                <option value="">Chọn học kỳ</option>
                <option value="1" 
                <?php if(old('semester')): ?>
                <?php echo e(changeSelectedStatus('1', old('semester'))); ?>

                <?php endif; ?>>Kỳ 1</option>
                <option value="2"
                <?php if(old('semester')): ?>
                <?php echo e(changeSelectedStatus('2', old('semester'))); ?>

                <?php endif; ?>>Kỳ 2</option>
              </select>
            </div>
          </div>
          
        </div>
        <div class="form-group col-md-2 offset-md-10">
          <button type="submit" class="btn btn-primary right"><i class="fas fa-filter"></i> Lọc</button>
        </div>
      </form>
    </div>
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <!-- Begin Page Content -->      
      <!-- DataTales Example -->
      <div class="card mb-4">
        
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
              <thead style="background: #f8f9fc">
                <tr>
                  <th></th>
                  <th>Mã chương trình</th>
                  <th>Tên chương trình</th>
                  <th>Thời gian diễn ra</th>
                  <th>Sinh viên đứng chính</th>
                  <th>Trạng thái</th>
                  <th>Số lượng đăng ký</th>
                  <th>Chương trình</th>
                  <th>Dự trù</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                  <td></td>
                  <td><?php echo e($activity->id); ?></td>
                  <td><?php echo e($activity->name); ?></td>
                  <td><?php echo e(date('d/m/Y',strtotime($activity->start_date))); ?> - <?php echo e(date('d/m/Y',strtotime($activity->end_date))); ?></td>
                  <td><?php echo e($activity->leadBy->name); ?> - <?php echo e($activity->leadBy->student_id); ?></td>
                  <td class="text-center"><?php echo changeActivityStatus($activity->start_date, $activity->end_date); ?></td>
                  <td><?php echo "0"; ?></td>
                  <td class="text-center">
                      <a class="cm-label text-info detailToggle" data-id="<?php echo e($activity->id); ?>" data-toggle="modal"><i class="fas fa-list" title="Chi tiết chương trình" data-toggle="tooltip" data-placement="top"></i></a>
                      <a href="<?php echo e(route('get_edit_activity',['id'=>$activity->id])); ?>"><i class="fas fa-edit cm-label text-primary" title="Chỉnh sửa chương trình" data-toggle="tooltip" data-placement="top"></i></a>
                    </td>
                  <td class="text-center">
                    <?php if($activity->fund == null): ?>
                    <a href="<?php echo e(route('get_add_activity_funding',['id'=>$activity->id])); ?>" class="btn btn-success btn-sm" title="Thêm dự trù" data-toggle="tooltip" data-placement="top"><i class="fas fa-plus-circle"></i></a>
                    <?php else: ?>
                    <a href="<?php echo e(route('get_edit_activity_funding',['id'=>$activity->fund->id])); ?>" class="btn btn-primary btn-sm" data-id="<?php echo e($activity->id); ?>" title="Chỉnh sửa dự trù" data-toggle="tooltip" data-placement="top"><i class="fas fa-edit cm-label text-white" ></i></a>
                    <a href="#" class="btn btn-danger btn-sm delete-fund-detail" data-content="<?php echo e($activity); ?>" title="Xóa dự trù" data-toggle="tooltip" data-placement="top"><i class="fas fa-trash-alt cm-label text-white"></i></a>
                    <?php endif; ?>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <a class="btn btn-success" href="<?php echo e(route('get_add_activity')); ?>"><i class="fas fa-plus-circle"></i> Thêm chương trình</a>
      <button onclick="deleteActivity()" class="btn" id="deleteUser" style="background-color: #D98880; color: #fff"><i class="fas fa-minus-circle"></i> Xóa chương trình</button>
    </div>
  </div>
  
  <div class="col-md-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb cm-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
        
      </ol>
    </nav>
  </div>
  <!-- Modal -->
  <div class="modal animated jackInTheBox" id="activityDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <!-- Page level plugins -->
  <script>
    var BASE_URL = "<?php echo e(asset('admin/activities/')); ?>";
    var BASE_FUNDING_URL = "<?php echo e(asset('admin/activities/funding')); ?>";
  </script>
  <script src="<?php echo e(asset('assets/js/admin/activity/list_activity.js')); ?>"></script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/activity/list_activity.blade.php */ ?>