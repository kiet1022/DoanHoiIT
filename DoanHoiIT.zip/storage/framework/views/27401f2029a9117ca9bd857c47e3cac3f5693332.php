<footer id="footer">
  <div class="container">
    <div class="row">
      
      <div class="col-md-4 col-sm-6">
        <div class="footer-info">
          <div class="section-title">
            <h2>Địa chỉ liên hệ</h2>
          </div>
          <address>
            <p>01 Võ Văn Ngân, phường Linh Chiểu<br>quận Thủ Đức, TP Hồ Chí Minh</p>
          </address>
        </div>
      </div>
      <div class="col-md-8 col-sm-12">
        <div class="footer-info">
          <div class="section-title">
            <h2>Thông tin liên lạc</h2>
          </div>
          <address>
            <p>Tuấn Kiệt: (+84)585839300</p>
            <p><a href="mailto:doanhoiitspkt@gmail.com">doanhoiitspkt@gmail.com</a></p>
          </address>
          
        </div>
      </div>
    </div>
    <div class="row text-center">
        
        
        <div class="copyright-text"> 
          <p>Copyright &copy; 2019 Đoàn TN - Hội SV Khoa Công nghệ Thông Tin ĐH SPKT TP.HCM</p>
        </div>
      </div>
  </div>
</footer>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/layout/footer.blade.php */ ?>