    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Thông tin chương trình</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        
        <form action="<?php echo e(route('edit_workflow_detail')); ?>" method="POST">
          <div class="modal-body">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <label for="leadr">Người đảm nhiệm</label>
              <input class="form-control" type="text" name="leader" value="<?php echo e($workflowDetail['of_student']['name']); ?>" readonly>
            </div>
            <div class="form-group">
              <label for="content">Nội dung công việc</label>
              <textarea name="contentDetail" class="form-control" cols="30" rows="4"><?php echo e($workflowDetail['content']); ?></textarea>
              <input type="hidden" name="id" value="<?php echo e($workflowDetail['id']); ?>"/>
            </div>
            <div class="card">
              <div class="card-header">
                <h5 class="card-title" style="color:red;">Chi tiết công việc</h5>
              </div>
              <div class="card-body" style="overflow-y: auto; max-height: 300px;">
                <ul class="list-group list-group-flush" id="detail-content">
                  <?php if(isset($workflowDetail['details'])): ?>
                  <?php $__currentLoopData = $workflowDetail['details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li class="list-group-item" id="card_<?php echo e($detail['id']); ?>">
                    <div class="form-row">
                      <div class="form-group cm-inline-form col-md-7">
                        <label for="content_<?php echo e($detail['id']); ?>">Tên</label>
                        <input id="content_<?php echo e($detail['id']); ?>" class="form-control" type="text" name="content_[]" value="<?php echo e($detail['content']); ?>">
                        <input type="hidden" name="workflowId_[]" value="<?php echo e($detail['id']); ?>">
                      </div>
                      
                      <div class="form-group cm-inline-form col-md-4">
                        <label for="progress_<?php echo e($detail['id']); ?>">Tiến độ (%)</label>
                        <input id="progress_<?php echo e($detail['id']); ?>" class="form-control" type="number" name="progress_[]" value="<?php echo e($detail['progress']); ?>">
                      </div>
                      
                      <div class="form-group cm-inline-form col-md-1 text-right">
                        <a class="add mr-1 text-success"><i class="fas fa-plus"></i></a>
                        <a class="delete text-danger" data-delete="<?php echo e($detail['id']); ?>"><i class="fas fa-minus "></i></a>
                      </div>
                    </div>
                  </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <li class="list-group-item" id="card_0">
                      <div class="form-row">
                        <div class="form-group cm-inline-form col-md-7">
                          <label for="content_0">Tên</label>
                          <input id="content_0" class="form-control" type="text" name="content_[]">
                          <input type="hidden" name="workflowId_[]" value="0">
                        </div>
                        
                        <div class="form-group cm-inline-form col-md-4">
                          <label for="progress_0">Tiến độ (%)</label>
                          <input id="progress_0" class="form-control" type="number" name="progress_[]">
                        </div>
                        
                        <div class="form-group cm-inline-form col-md-1 text-right">
                          <a class="add mr-1 text-success"><i class="fas fa-plus"></i></a>
                          <a class="delete text-danger" data-delete="0"><i class="fas fa-minus "></i></a>
                        </div>
                      </div>
                    </li>
                  <?php endif; ?>
                </ul>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-success" style="width: 100%">Lưu</button>
          </div>
        </form>
      </div>
    </div>

<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/workflow/modal_workflow_detail.blade.php */ ?>