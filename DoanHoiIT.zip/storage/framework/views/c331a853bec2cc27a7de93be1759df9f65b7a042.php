<?php $__env->startSection('title'); ?>
<?php echo e($activity->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('pages/css/new.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- section -->
<!-- Page Header -->
<div id="post-header" class="page-header" style="padding-top: 10%; padding-bottom: 10%;">
  <div class="background-img" style="background-image: url('<?php echo e(asset('assets/fileupload/activities/images/'.$activity->image)); ?>');"></div>
  
  <div class="container">
    <div class="row">
      <div class="col-md-10">
        <div class="post-meta">
          
          
        </div>
        <h1><?php echo e($activity->name); ?></h1>
      </div>
    </div>
  </div>
</div>
<!-- /Page Header -->
<!-- container -->
<div class="container" style="margin-top: 15px">
  <!-- row -->
  <div class="row">
    <!-- Post content -->
    <div class="col-md-8">
      <div class="section-row sticky-container">
        <div class="main-post">
          <h3 style="color: #4e73df">Thông tin chương trình</h3>
          <table class="table table-striped">
            <tbody>
              <tr>
                <th>Tên chương trình</th>
                <td><?php echo e($activity->name); ?></td>
              </tr>
              <tr>
                <th>Thời hạn đăng ký</th>
                <td>Từ ngày <?php echo e(date('d/m/Y',strtotime($activity->start_regis_date))); ?> đến ngày <?php echo e(date('d/m/Y',strtotime($activity->end_regis_date))); ?></td>
              </tr>
              
              <tr>
                <th>Số lượng đăng ký</th>
                <td><?php echo e($activity->register_number); ?></td>
              </tr>
              
              <tr>
                <th>Thời gian diễn ra chương trình</th>
                <td>Từ ngày <?php echo e(date('d/m/Y',strtotime($activity->start_date))); ?> đến ngày <?php echo e(date('d/m/Y',strtotime($activity->end_date))); ?></td>
              </tr>
              
              <tr>
                <th>Nội dung</th>
                <td><?php echo $activity->content; ?></td>
              </tr>
              
              <tr>
                <th>Điểm cộng</th>
                <td>
                  <?php if($activity->practise_marks > 0): ?>
                      <?php echo e($activity->practise_marks); ?> ĐRL
                  <?php elseif($activity->social_marks > 0): ?>
                    <?php echo e($activity->practise_marks); ?> Điểm CTXH
                  <?php endif; ?>
                </td>
              </tr>
              <tr>
                <th>Liên hệ</th>
              <td><?php echo e($activity->leadBy->name); ?> <br> Email: <?php echo e($activity->leadBy->user->email); ?></td>
              </tr>
              <tr>
                <?php if(auth()->guard()->check()): ?>
                <td colspan="2" class="text-center">
                  <?php if($isAttend): ?>
                  <form action="<?php echo e(route('cancel_regis_activity')); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="activity_id" value="<?php echo e($activity->id); ?>">
                      <button class="btn btn-danger" type="submit">Hủy đăng ký</button>
                  </form>
                  <?php else: ?>
                  <form action="<?php echo e(route('attend_activity')); ?>" method="POST">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="activity_id" value="<?php echo e($activity->id); ?>">
                      <button class="btn" type="submit" style="background-color: #4e73df;color: white;">Đăng ký</button>
                  </form>
                  <?php endif; ?>
                </td>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                <td colspan="2" class="text-center">
                    <span class="label label-warning" style="font-size: 100%">Vui lòng đăng nhập để đăng kí tham gia chương trình</span>
                </td>
                <?php endif; ?>
              </tr>
            </tbody>
          </table>
          
        </div>
        <div class="post-shares sticky-shares">
          <a href="https://www.facebook.com/DoanHoiITUTE/" target="_blank" class="share-facebook"><i class="fa fa-facebook"></i></a>
          <a href="mailto:doaihoiitspkt@gmail.com" class="share-google-plus" target="_blank"><i class="fa fa-google-plus"></i></a>
          <a href="http://fit.hcmute.edu.vn/" class="share-website" target="_blank"><i class="fa fa-globe"></i></a>
        </div>
      </div>                         
    </div>
    <!-- /Post content -->
    
    <!-- aside -->
    <div class="col-md-4">
      <!-- ad -->
      <div class="col-md-12 text-center" style="margin-bottom: 15px; padding: 0">
        <div class="col-md-8 badge-header-primary">
          <h4 style="color: white; margin: 5px">Chương trình tháng <?php echo e((\Carbon\Carbon::now())->format('m')); ?></h4>
        </div>
        <div class="col-md-12" style="border-bottom: 2px solid #4e73df ;">
        </div>
      </div>
      <div class="aside-widget">
        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post post-widget">
          <a class="post-img" href="<?php echo e(route('user_get_activity_detail',['id'=>$act->id])); ?>">
              <?php if($act->image): ?>
              <img style="width: 90px; height: 49px;" src="<?php echo e(asset('assets/fileupload/activities/images/'.$act->image)); ?>" alt="Lỗi">
              <?php else: ?>
              <img style="width: 90px; height: 49px;" src="<?php echo e(asset('assets/img/faculty_banner.png')); ?>" alt="Lỗi">
              <?php endif; ?>
          </a>
          <div class="post-body">
            <h3 class="post-title"><a href="<?php echo e(route('user_get_activity_detail',['id'=>$act->id])); ?>"><?php echo e($act->name); ?></a></h3>
            <span class="post-date">Thời gian: <?php echo e(date('d/m/Y',strtotime($act->start_date))); ?> - <?php echo e(date('d/m/Y',strtotime($act->end_date))); ?></span>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <!-- /ad -->
      
      <!-- post widget -->
      
      <!-- /post widget -->
      
      <!-- catagories -->
      
      <!-- /catagories -->
    </div>
    <!-- /aside -->
  </div>
  <!-- /row -->
</div>
<!-- /container -->
</div>
<!-- /section -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    <?php if(session('error')): ?>
    var error = "<?php echo e(session('error')); ?>";
    showNotify('error',error);
    <?php endif; ?>
    <?php if(session('success')): ?>
    var success = "<?php echo e(session('success')); ?>";
    console.log(success)
    showNotify('success',success);
    <?php endif; ?>

    $('form').on('submit', function(){
      blockUI(true);
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/activity_detail.blade.php */ ?>