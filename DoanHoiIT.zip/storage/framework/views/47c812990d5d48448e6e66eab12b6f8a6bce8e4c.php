<?php $__env->startSection('title'); ?>
Danh mục tin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>
  <!-- PAGE HEADER -->
    <div class="page-header">
      <div class="page-header-bg" style="background-image: url('<?php echo e(asset('assets/img/user/banner.jpg')); ?>');" data-stellar-background-ratio="0.5"></div>
      <div class="container">
        <div class="row">
          <div class="col-md-offset-1 col-md-10 text-center">
            <h1 class="text-uppercase"></h1>
          </div>
        </div>
      </div>
    </div>
    <!-- /PAGE HEADER -->
<!-- SECTION -->
  <div class="section">
    <!-- container -->
    <div class="container">
      <!-- row -->
      <div class="row">
        <div class="col-md-8">

          <!-- post -->
           <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="post post-row">
            <a class="post-img" href="<?php echo e(route('get_new',['id'=>$list->id])); ?>">
              <?php if($list->image != ""): ?> 
                  <img src="<?php echo e(asset('images/news')); ?>/<?php echo e($list->image); ?>" alt="">
                  <?php else: ?> 
                              <img src="<?php echo e(asset('assets/img/image-not-available.png')); ?>" alt="Colorlib">
                   <?php endif; ?>
            </a>
            <div class="post-body">
              <div class="post-category">
                <a href="<?php echo e(route('get_new_by_ctg',['id'=>$list->ofType->id])); ?>"><?php echo e($list->ofType->name); ?></a>
              </div>
              <h3 class="post-title"><a href="<?php echo e(route('get_new',['id'=>$list->id])); ?>"><?php echo e($list->title); ?></a></h3>
              <ul class="post-meta">
                <li><a href="#"><?php echo e($list->ofUser->student->name); ?></a></li>
                <li><?php echo e($list->created_at->format('F j Y')); ?></li>
              </ul>
              <p><?php echo e($list->sumary); ?></p>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- /post -->
        </div>

        <?php echo $__env->make('user.layout.sideBarRight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/user/news/category.blade.php */ ?>