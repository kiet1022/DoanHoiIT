<?php $__env->startSection('title'); ?>
Trang chủ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main_content'); ?>

  <!-- SECTION -->
  <div class="section">
    <!-- container -->
    <div class="container">
      <!-- row -->
      <div id="hot-post" class="row hot-post">
        <div class="col-md-8 hot-post-left">
          <!-- post -->
          <?php if(isset($lastedNews1)): ?>
          <div class="post post-thumb">
            <a class="post-img" href="<?php echo e(route('get_new',['id'=>$lastedNews1->id])); ?>">
              <?php if($lastedNews1->image != ""): ?> 
                <img src="<?php echo e(asset('images/news')); ?>/<?php echo e($lastedNews1->image); ?>" alt="">
              <?php else: ?> 
                <img src="<?php echo e(asset('assets/img/image-not-available.png')); ?>" alt="Colorlib">
              <?php endif; ?></a>
            <div class="post-body">
              <div class="post-category">
                <a href="category.html"><?php echo e($lastedNews1->ofType->name); ?></a>
              </div>
              <h3 class="post-title title-lg"><a href="<?php echo e(route('get_new',['id'=>$lastedNews1->id])); ?>"><?php echo e($lastedNews1->title); ?></a></h3>
              <ul class="post-meta">
                <li><a href="author.html"><?php echo e($lastedNews1->ofUser->student->name); ?></a></li>
                <li><?php echo e($lastedNews1->created_at->format('F j Y')); ?></li>
              </ul>
            </div>
          </div>
          <?php endif; ?>
          <!-- /post -->
        </div>
        <div class="col-md-4 hot-post-right">
           <?php if(isset($lastedNews2)): ?>
          <!-- post -->
          <div class="post post-thumb">
            <a class="post-img" href="<?php echo e(route('get_new',['id'=>$lastedNews2->id])); ?>">
              <?php if($lastedNews2->image != ""): ?> 
              <img src="<?php echo e(asset('images/news')); ?>/<?php echo e($lastedNews2->image); ?>" alt="">
            <?php else: ?> 
                <img src="<?php echo e(asset('assets/img/image-not-available.png')); ?>" alt="Colorlib">
              <?php endif; ?></a>
            <div class="post-body">
              <div class="post-category">
                <a href="category.html"><?php echo e($lastedNews2->ofType->name); ?></a>
              </div>
              <h3 class="post-title"><a href="<?php echo e(route('get_new',['id'=>$lastedNews2->id])); ?>"><?php echo e($lastedNews2->title); ?></a></h3>
              <ul class="post-meta">
                <li><a href="author.html"><?php echo e($lastedNews2->ofUser->student->name); ?></a></li>
                <li><?php echo e($lastedNews2->created_at->format('F j Y')); ?></li>
              </ul>
            </div>
          </div>
          <!-- /post -->
          <?php endif; ?>
          <!-- post -->
           <?php if(isset($lastedNews3)): ?>
          <div class="post post-thumb">
            <a class="post-img" href="<?php echo e(route('get_new',['id'=>$lastedNews3->id])); ?>">
              <?php if($lastedNews3->image != ""): ?> 
              <img src="<?php echo e(asset('images/news')); ?>/<?php echo e($lastedNews3->image); ?>" alt="">
            <?php else: ?> 
                <img src="<?php echo e(asset('assets/img/image-not-available.png')); ?>" alt="Colorlib">
              <?php endif; ?></a>
            <div class="post-body">
              <div class="post-category">
                <a href="category.html"><?php echo e($lastedNews3->ofType->name); ?></a>
              </div>
              <h3 class="post-title"><a href="<?php echo e(route('get_new',['id'=>$lastedNews3->id])); ?>"><?php echo e($lastedNews3->title); ?></a></h3>
              <ul class="post-meta">
                <li><a href="author.html"><?php echo e($lastedNews3->ofUser->student->name); ?></a></li>
                <li><?php echo e($lastedNews3->created_at->format('F j Y')); ?></li>
              </ul>
            </div>
          </div>
          <!-- /post -->
          <?php endif; ?>
        </div>
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /SECTION -->

  <!-- SECTION -->
  <div class="section">
    <!-- container -->
    <div class="container">
      <!-- row -->
      <div class="row">
        <div class="col-md-8">
          <!-- row -->
          <div class="row">
            <div class="col-md-12">
              <div class="section-title">
                <h2 class="title">Recent posts</h2>
              </div>
            </div>
            <!-- post -->
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6">
              <div class="post">
                <a class="post-img" href="<?php echo e(route('get_new',['id'=>$list->id])); ?>">
                  <?php if($list->image != ""): ?> 
                  <img src="<?php echo e(asset('images/news')); ?>/<?php echo e($list->image); ?>" alt="">
                  <?php else: ?> 
                              <img src="<?php echo e(asset('assets/img/image-not-available.png')); ?>" alt="Colorlib">
                   <?php endif; ?>
                </a>
                <div class="post-body">
                  <div class="post-category">
                    <a href="category.html"><?php echo e($list->ofType->name); ?></a>
                  </div>
                  <h3 class="post-title"><a href="blog-post.html"><?php echo e($list->title); ?></a></h3>
                  <ul class="post-meta">
                    <li><a href="author.html"><?php echo e($list->ofUser->student->name); ?></a></li>
                    <li><?php echo e($list->created_at->format('F j Y')); ?></li>
                  </ul>
                </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <!-- /post -->
          </div>
          <!-- /row -->
        </div>
        <?php echo $__env->make('user.layout.sideBarRight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /SECTION -->

  <!-- SECTION -->
  <div class="section">
    <!-- container -->
    <div class="container">
      <!-- row -->
      <div class="row">
        <div class="col-md-8">
          <div class="section-row loadmore text-center">
            <a href="#" class="primary-button">Load more</a>
          </div>
        </div>
      </div>
      <!-- /row -->
    </div>
    <!-- /container -->
  </div>
  <!-- /SECTION -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/user/index.blade.php */ ?>