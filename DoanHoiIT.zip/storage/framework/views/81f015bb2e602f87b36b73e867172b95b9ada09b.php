<!DOCTYPE html>
<html lang="en">
<head>
     
     <title><?php echo $__env->yieldContent('title'); ?></title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
     <link rel="shortcut icon" href="<?php echo e(asset('assets/img/faculty_banner.png')); ?>"> 
     <base href="<?php echo e(asset('')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/bootstrap-3.3.6/dist/css/bootstrap.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/font-awesome.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/owl.carousel.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/owl.theme.default.min.css')); ?>">
     
     <!-- MAIN CSS -->
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/templatemo-style.css')); ?>">
     <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
     <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/animate.css-master/animate.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/font-awesome.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap4-dialog/css/bootstrap-dialog.min.css')); ?>" >
     <?php echo $__env->yieldContent('style'); ?>
     <style>
          .dropdown:hover .dropdown-menu {
               display: block;
          }
     </style>
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
     <!-- PRE LOADER -->
     <!-- MENU -->
     <?php echo $__env->make('student.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- HOME -->
     <?php echo $__env->yieldContent('extends'); ?>
     
     <!-- ABOUT -->
     <?php echo $__env->yieldContent('content'); ?>
     <!-- FOOTER -->
     <?php echo $__env->make('student.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- SCRIPTS -->
     <script src="<?php echo e(asset('pages/js/jquery.js')); ?>"></script>
     <script src="<?php echo e(asset('pages/css/bootstrap-3.3.6/dist/js/bootstrap.min.js')); ?>"></script>
     <script src="<?php echo e(asset('pages/js/owl.carousel.min.js')); ?>"></script>
     <script src="<?php echo e(asset('pages/js/smoothscroll.js')); ?>"></script>
     <script src="<?php echo e(asset('pages/js/custom.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/bootstrap-notify-master/bootstrap-notify.min.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/bootstrap4-dialog/js/bootstrap-dialog.min.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/jquery.blockUI.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/js/common.js')); ?>"></script>
     <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/layout/index.blade.php */ ?>