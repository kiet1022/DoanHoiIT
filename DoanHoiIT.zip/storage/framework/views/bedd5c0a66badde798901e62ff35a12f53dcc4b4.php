<?php $__env->startSection('title'); ?>
<?php echo e($detail->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link rel="stylesheet" href="<?php echo e(asset('pages/css/new.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- section -->
<!-- Page Header -->
<div id="post-header" class="page-header">
  <div class="background-img" style="background-image: url('<?php echo e(asset('images/news/'.$detail->image)); ?>');"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-10">
        <div class="post-meta">
          <a class="post-category <?php echo e(changeCatColor($detail->type_id)); ?>" href="category.html"><?php echo e($detail->ofType->name); ?></a>
          <span class="post-date">Ngày đăng: <?php echo e(date('d/m/Y',strtotime($detail->created_at))); ?></span>
        </div>
        <h1><?php echo e($detail->title); ?></h1>
      </div>
    </div>
  </div>
</div>
<!-- /Page Header -->
<!-- container -->
<div class="container">
  <!-- row -->
  <div class="row">
    <!-- Post content -->
    <div class="col-md-8">
      <div class="section-row sticky-container">
        <div class="main-post">
          <?php echo $detail->content; ?>

        </div>
        <div class="post-shares sticky-shares">
          <a href="https://www.facebook.com/DoanHoiITUTE/" target="_blank" class="share-facebook"><i class="fa fa-facebook"></i></a>
          <a href="mailto:doaihoiitspkt@gmail.com" class="share-google-plus" target="_blank"><i class="fa fa-google-plus"></i></a>
          <a href="http://fit.hcmute.edu.vn/" class="share-website" target="_blank"><i class="fa fa-globe"></i></a>
        </div>
      </div>                         
    </div>
    <!-- /Post content -->
    
    <!-- aside -->
    <div class="col-md-4">
      <!-- ad -->
      <div class="aside-widget text-center">
        <a href="#" style="display: inline-block;margin: auto;">
          <img class="img-responsive" src="./img/ad-1.jpg" alt="">
        </a>
      </div>
      <!-- /ad -->
      
      <!-- post widget -->
      <div class="aside-widget">
        <div class="col-md-12 text-center" style="margin-bottom: 15px; padding: 0">
          <div class="col-md-7 badge-header-warning">
            <h4 style="color: white; margin: 5px">Bài viết cùng chủ đề</h4>
          </div>
          <div class="col-md-12" style="border-bottom: 2px solid #f4b619 ;">
          </div>
        </div>
        <?php $__currentLoopData = $relatedPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post post-thumb">
          <a class="post-img" href="<?php echo e(route('get_new_detail',['id'=>$rl->id])); ?>">
            <img src="<?php echo e(asset('images/news/'.$rl->image)); ?>" alt="Lỗi" style="width: 360px; height: 197px;">
          </a>
          <div class="post-body">
            <div class="post-meta">
              <a class="post-category <?php echo e(changeCatColor($rl->type_id)); ?>" href=""><?php echo e($rl->ofType->name); ?></a>
              <span class="post-date">Ngày đăng: <?php echo e(date('d/m/Y',strtotime($rl->created_at))); ?></span>
            </div>
            <h3 class="post-title"><a href="<?php echo e(route('get_new_detail',['id'=>$rl->id])); ?>"><?php echo e($rl->title); ?></a></h3>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      <!-- /post widget -->
      
					<!-- catagories -->
					<div class="aside-widget">
						<div class="col-md-12 text-center" style="margin-bottom: 15px; padding: 0">
							<div class="col-md-6 badge-header-danger">
								<h4 style="color: white; margin: 5px">Danh mục tin tức</h4>
							</div>
							<div class="col-md-12" style="border-bottom: 2px solid #e74a3b ;">
							</div>
						</div>
						
						<div class="category-widget">
							<ul>
								<?php $__currentLoopData = $newsType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li><a href="#" class="<?php echo e(changeCatColor($nt->id)); ?>"><?php echo e($nt->name); ?><span><?php echo e(count($nt->news)); ?></span></a></li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						</div>
					</div>
					<!-- /catagories -->
    </div>
    <!-- /aside -->
  </div>
  <!-- /row -->
</div>
<!-- /container -->
</div>
<!-- /section -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layout.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/news-detail.blade.php */ ?>