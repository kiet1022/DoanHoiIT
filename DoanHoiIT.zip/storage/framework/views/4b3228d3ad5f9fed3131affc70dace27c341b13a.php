<?php $__env->startSection('title','Tiến độ công việc'); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/admin/activity/workflow_list.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="row">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
                <li class="breadcrumb-item"><i class="fas fa-angle-right"></i> Quản lý chương trình</li>
                <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('get_list_activity')); ?>"> Danh sách chương trình</a></li>
                <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Tiến độ công việc</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col page-title-header">
            <h4>Tiến độ công việc</h4>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
            <form action="<?php echo e(route('get_workflow_filter')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-row">
                    
                    <div class="form-group col-4 offset-md-4">
                        <label for="activity" class="col-md-12 common-label-inline">Chương trình:</label>
                        <div class="col-md-12 col-sm-12 col-xs-12 px-0 d-flex">
                            <select name="activity" id="activity" class="form-control col-md-8 col-sm-8 col-xs-8">
                                <option value="">Chọn chương trình</option>
                                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($a->id); ?>" <?php echo changeSelectedStatus("$a->id", old('activity') ); ?> 
                                    <?php if(session('workflows')): ?><?php echo changeSelectedStatus("$a->id", session('workflows')[0]->ofActivity->id."" ); ?> <?php endif; ?> ><?php echo e($a->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button class="btn btn-primary ml-3" type="submit">Xem tiến độ</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <?php if(isset($workflows)): ?>
    <?php if(count($workflows) > 0): ?>
    <div class="row custom_panel">
        
        <div class="col-md-12 col-sm-12 col-xs-12 d-flex flex-wrap p-0" id="in-card-content">
            <?php $__currentLoopData = $workflows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workflow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4">
                <div class="card" style="height: 100%">
                    <div class="card-header">
                        <h5 class="card-title" style="color:red;"><?php echo e($workflow->ofStudent->name); ?></h5>
                    </div>
                    <div class="card-body">
                        <p class="card-text"><h5 class="text-primary"><?php echo e($workflow->content); ?></h5></p>
                        <ul class="list-group list-group-flush">
                            <?php $__currentLoopData = $workflow->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <?php echo e($detail->content); ?>

                                <div class="progress">
                                    <div class="progress-bar <?php echo e(changeProgressbarColor($detail->progress)); ?>" role="progressbar" aria-valuenow="<?php echo e($detail->progress); ?>" aria-valuemin="0" aria-valuemax="<?php echo e($detail->progress); ?>" style='width:<?php echo e($detail->progress); ?>%'><?php echo e($detail->progress); ?>%</div>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="card-footer">
                        <?php if($workflow->student_id === Auth::user()->student->student_id): ?>
                        <div class="d-flex m-1">
                            <a href="#" class="btn btn-primary btn-sm detail mr-1" style="width:50%" data-content="<?php echo e($workflow); ?>"><i class="fas fa-edit"></i> Chỉnh sửa</a>
                            <a href="<?php echo e(route('delete_workflow',['id'=>$workflow->id])); ?>" class="btn btn-danger btn-sm ml-1" style="width:50%" "><i class="fas fa-minus"></i> Xóa</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php else: ?>
    <div class="row custom_panel text-center">
        <div class="col-md-12 col-sm-12 col-xs-12 p-0" id="in-card-content">
            <span class="badge badge-warning">Chương trình này chưa được phân công công việc</span>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    
    
    <?php if(session('workflows')): ?>
    <?php if(count(session('workflows')) > 0): ?>
    <div class="row custom_panel">
        
        <div class="col-md-12 col-sm-12 col-xs-12 d-flex flex-wrap p-0" id="in-card-content">
            <?php $__currentLoopData = session('workflows'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workflow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4">
                <div class="card" style="height: 100%">
                    <div class="card-header">
                        <h5 class="card-title" style="color:red;"><?php echo e($workflow->ofStudent->name); ?></h5>
                    </div>
                    <div class="card-body">
                        <p class="card-text"><h5 class="text-primary"><?php echo e($workflow->content); ?></h5></p>
                        <ul class="list-group list-group-flush">
                            <?php $__currentLoopData = $workflow->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item">
                                <?php echo e($detail->content); ?>

                                <div class="progress">
                                    <div class="progress-bar <?php echo e(changeProgressbarColor($detail->progress)); ?>" role="progressbar" aria-valuenow="<?php echo e($detail->progress); ?>" aria-valuemin="0" aria-valuemax="<?php echo e($detail->progress); ?>" style='width:<?php echo e($detail->progress); ?>%'><?php echo e($detail->progress); ?>%</div>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="card-footer">
                        <?php if($workflow->student_id === Auth::user()->student->student_id): ?>
                        <div class="d-flex m-1">
                            <a href="#" class="btn btn-primary btn-sm detail mr-1" style="width:50%" data-content="<?php echo e($workflow); ?>"><i class="fas fa-edit"></i> Chỉnh sửa</a>
                            <a href="<?php echo e(route('delete_workflow',['id'=>$workflow->id])); ?>" class="btn btn-danger btn-sm ml-1" style="width:50%" "><i class="fas fa-minus"></i> Xóa</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php else: ?>
    <div class="row custom_panel text-center">
        <div class="col-md-12 col-sm-12 col-xs-12 p-0" id="in-card-content">
            <span class="badge badge-warning">Chương trình này chưa được phân công công việc</span>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>

<div class="col-12">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb cm-breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
            
        </ol>
    </nav>
</div>
<!-- Modal -->
<div class="modal animated jackInTheBox" id="workflowDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Page level plugins -->
<script>
    var BASE_URL = "<?php echo e(asset('admin/activities/workflow')); ?>";
    <?php if(session('error')): ?>
    var error = "<?php echo e(session('error')); ?>";
    showNotify('error',error);
    <?php endif; ?>
    <?php if(session('success')): ?>
    var success = "<?php echo e(session('success')); ?>";
    showNotify('success',success);
    <?php endif; ?>
</script>
<script src="<?php echo e(asset('assets\js\admin\workflow\workflow_list.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/workflow/list_workflow.blade.php */ ?>