<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
  <link rel="shortcut icon" href="<?php echo e(asset('assets/img/faculty_banner.png')); ?>"> 
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<title><?php echo $__env->yieldContent('title'); ?></title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:400,700%7CMuli:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/student/bootstrap.min.css')); ?>" />

	<!-- Font Awesome Icon -->
	<link href="<?php echo e(asset('assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="<?php echo e(asset('assets/css/student/style.css')); ?>" />
	<?php echo $__env->yieldContent('style'); ?>
</head>

<body>

<?php echo $__env->make('student.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<!-- FOOTER -->
<?php echo $__env->make('student.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="<?php echo e(asset('assets/js/student/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/student/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/student/jquery.stellar.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/student/main.js')); ?>"></script>
	<?php echo $__env->yieldContent('js'); ?>
</body>

</html>

<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/layout/layout.blade.php */ ?>