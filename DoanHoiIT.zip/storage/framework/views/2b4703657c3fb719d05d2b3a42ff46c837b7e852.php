<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/administrators/executive_committee_list.blade.php */ ?>
<?php $__env->startSection('title'); ?>
Danh sách ban chấp hành
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/vendor/datatables/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/datatables/css/select.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/admin/common.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/admin/common2.css')); ?>" rel="stylesheet" type="text/css">

<style>
    .no-js #loader { display: none;  }
    .js #loader { display: block; position: absolute; left: 100px; top: 0; }
    .se-pre-con {
        position: fixed;
        left: 0px;
        top: 0px;
        width: 100%;
        height: 100%;
        z-index: 9999;
        background: url("<?php echo e(asset('assets/img/Preloader_1.gif')); ?>") center no-repeat #fff;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col page-title-header">
                <h4>Quản lý ban chấp hành</h4>
        </div>
    </div>
    <div class="row">
        
        <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
           
        </div>
        
        <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
            
                    <!-- Begin Page Content -->      
                <!-- DataTales Example -->
                <div class="card mb-4">
                  <div class="card-header py-3 text-center">
                      <div class="btn-group" role="group" aria-label="Basic example">
                          <button type="button" class="btn btn-primary">BCH Đoàn</button>
                          <button type="button" class="btn btn-primary">BCH Liên Chi hội</button>
                        </div>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead style="background: #f8f9fc">
                          <tr>
                            <th></th>
                            <th>MSSV</th>
                            <th>Họ tên</th>
                            <th>Email</th>
                            <th>Quyền</th>
                            <th></th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td></td>
                            <td><?php echo e($list->student_id); ?></td>
                            <td><?php echo e($list->student->name); ?></td>
                            <td><?php echo e($list->email); ?></td>
                            <td> 
                              <?php if( $list->level == '1' ): ?>
                              Thường trực
                              <?php elseif( $list->level == '2' ): ?>
                              Ủy viên BCH
                              <?php elseif( $list->level == '3' ): ?>
                              Ban cán sự lớp
                              <?php endif; ?>
                            </td>
                            <td><i class="far fa-edit"></i> <a href="<?php echo e(route('get_edit_student',['id'=>$list->student_id])); ?>">Sửa</a></td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              <!-- /.container-fluid -->
              <a class="btn btn-success" href="<?php echo e(route('get_add_student')); ?>"><i class="fas fa-plus-circle"></i> Thêm 1 sinh viên</a>
                  <button class="btn btn-info"><i class="fas fa-file-import"></i> Import Sinh viên</button>
                  <button class="btn" style="background-color: #D98880; color: #fff"><i class="fas fa-minus-circle"></i> Xóa</button>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
 <!-- Page level plugins -->
<script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.select.min.js')); ?>"></script>
 <!-- Page level custom scripts -->
 
<script>
    $( document ).ready(function(){
        $('#dataTable').DataTable({
        columnDefs: [ {
            orderable: false,
            className: 'select-checkbox',
            targets:   0
        } ],
        select: {
            style:    'os',
            selector: 'td:first-child'
        },
        order: [[ 1, 'asc' ]]
    });
        });
    </script>
    <script>
        //paste this code under the head tag or in a separate js file.
        //Wait for window load
        // $(window).load(function() {
            // 	// Animate loader off screen
            // 	$(".se-pre-con").fadeOut("slow");
            // });
        </script>
        
        
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>