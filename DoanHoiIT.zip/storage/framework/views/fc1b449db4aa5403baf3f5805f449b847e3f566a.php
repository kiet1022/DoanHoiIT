<?php $__env->startSection('title', 'Dự trù kinh phí'); ?>
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
  <div class="row">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
        <li class="breadcrumb-item"><i class="fas fa-angle-right"></i> Quản lý Users</li>
        <li class="breadcrumb-item"><i class="fas fa-angle-right"></i><a href="<?php echo e(route('get_user_list')); ?>"> Danh sách user</a></li>
        <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Phân quyền</li>
      </ol>
    </nav>
  </div>
  <div class="row">
    <div class="col page-title-header">
      <h4>Danh sách quyền truy cập</h4>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">   
      <!-- DataTales Example -->
      <div class="card mb-4">
        
        <div class="card-body">
          <div class="form-row">
            <div class="form-group col-3">
              <label for="id">ID người dùng:</label>
              <input type="text" class="form-control" name="id" id="id" value="<?php echo e($user->id); ?>" readonly>
            </div>
            
            <div class="form-group col-3">
              <label for="student_id">MSSV:</label>
              <input type="text" class="form-control" name="student_id" id="student_id" value="<?php echo e($user->student_id); ?>" readonly>
            </div>
            
            <div class="form-group col-3">
              <label for="name">Họ tên:</label>
              <input type="text" class="form-control" name="name" id="name" value="<?php echo e($user->student->name); ?>" readonly>
            </div>
          </div>
        </div>
        
      </div>
      
      <!-- DataTales Example -->
      <div class="card mb-4">
        
        <div class="card-body">
          <form action="<?php echo e(route('post_attach_role')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-row">
              <input type="hidden" name="iduser" value="<?php echo e($user->id); ?>">
              
              <div class="form-group cm-inline-form col-md-3">
                <label for="0" class="col-md-12 p-0">Toàn quyền</label>
                <input class="form-control" id="toggleisUnion_0" name="status" type="checkbox" data-width="170" data-height="20">
              </div>
              <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="form-group cm-inline-form col-md-3">
                <label for="<?php echo e($role->id); ?>" class="col-md-12 p-0"><?php echo e($role->name); ?></label>
                <input class="form-control toggleisUnion" id="<?php echo e($role->id); ?>" name="role_id[]" type="checkbox" data-width="170" data-height="20" value="<?php echo e($role->id); ?>"
                <?php echo e(changeCheckedRoleStatus($ownRoles,"$role->id")); ?>>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
          
        </div>
        
      </div>
      <div class="text-center">
          <button class="btn btn-success" data-toggle="modal" type="submit"><i class="fas fa-plus-circle"></i> Cập nhật</button>
      </div>
    </form>
    </div>
  </div>
  
  <div class="col-md-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb cm-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
        
      </ol>
    </nav>
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <!-- Page level plugins -->
  <script>
    var BASE_URL = "<?php echo e(asset('admin/activities/funding')); ?>";
  </script>
  <script>
    <?php if(session('error')): ?>
    var error = "<?php echo e(session('error')); ?>";
    showNotify('error',error);
    <?php endif; ?>
    <?php if(session('success')): ?>
    var success = "<?php echo e(session('success')); ?>";
    showNotify('success',success);
    <?php endif; ?>
  </script>
  <script src="<?php echo e(asset('assets/js/admin/user/roles_list.js')); ?>"></script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/user/attach_roles.blade.php */ ?>