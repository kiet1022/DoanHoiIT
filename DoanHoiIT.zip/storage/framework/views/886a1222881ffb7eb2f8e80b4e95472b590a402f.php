<div class="col-md-4">
  <!-- ad widget-->
  <div class="aside-widget text-center">
    <a href="#" style="display: inline-block;margin: auto;">
      <img class="img-responsive" src="./img/ad-3.jpg" alt="">
    </a>
  </div>
  <!-- /ad widget -->

  <!-- category widget -->
  <div class="aside-widget">
    <div class="section-title">
      <h2 class="title">Categories</h2>
    </div>
    <div class="category-widget">
      <ul>
        <?php $__currentLoopData = $newsType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route('get_new_by_ctg',['id'=>$sy->id])); ?>"><?php echo e($sy->name); ?> <span>(12)</span></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
  </div>
  <!-- /category widget -->
  <!-- post widget -->
  <div class="aside-widget">
    <div class="section-title">
      <h2 class="title">Bài viết mới</h2>
    </div>

    <!-- post -->
    <?php $__currentLoopData = $lastedNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="post post-widget">
      <a class="post-img" href="<?php echo e(route('get_new',['id'=>$list->id])); ?>">
        <?php if($list->image != ""): ?>
        <img src="<?php echo e(asset('images/news')); ?>/<?php echo e($list->image); ?>" alt="">
        <?php else: ?>
        <img src="<?php echo e(asset('assets/img/image-not-available.png')); ?>" alt="Colorlib">
        <?php endif; ?>
      </a>
      <div class="post-body">
        <div class="post-category">
          <a href="<?php echo e(route('get_new_by_ctg',['id'=>$list->ofType->id])); ?>"><?php echo e($list->ofType->name); ?></a>
        </div>
        <h3 class="post-title"><a href="<?php echo e(route('get_new',['id'=>$list->id])); ?>"><?php echo e($list->title); ?></a></h3>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- /post -->
  </div>
  <!-- /post widget -->

  <!-- newsletter widget -->
  <!-- <div class="aside-widget">
    <div class="section-title">
      <h2 class="title">Newsletter</h2>
    </div>
    <div class="newsletter-widget">
      <form>
        <p>Nec feugiat nisl pretium fusce id velit ut tortor pretium.</p>
        <input class="input" name="newsletter" placeholder="Enter Your Email">
        <button class="primary-button">Subscribe</button>
      </form>
    </div>
  </div> -->
  <!-- /newsletter widget -->

  <!-- Ad widget -->
  <div class="aside-widget text-center">
    <a href="#" style="display: inline-block;margin: auto;">
      <img class="img-responsive" src="./img/ad-1.jpg" alt="">
    </a>
  </div>
  <!-- /Ad widget -->
</div>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/user/layout/sideBarRight.blade.php */ ?>