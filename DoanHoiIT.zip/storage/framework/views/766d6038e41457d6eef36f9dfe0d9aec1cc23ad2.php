<?php /* D:\xampp\htdocs\DoanHoi\resources\views/admin/students/student_list.blade.php */ ?>
<?php $__env->startSection('title'); ?>
Danh sách sinh viên
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/vendor/datatables/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/vendor/datatables/css/select.dataTables.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/css/admin/common.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/css/admin/common2.css')); ?>" rel="stylesheet" type="text/css">

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col page-title-header">
      <h4>Quản lý sinh viên</h4>
    </div>
  </div>
  <div class="row">
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
    <form action="<?php echo e(route('post_filter_student')); ?>" method="POST" class="col-md-12">
      <?php echo csrf_field(); ?>
        <div class="form-row">
          <div class="form-group col-md-3 offset-md-3">
            <label for="studentShoolYear" class="col-md-4 common-label-inline">Niên khóa <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
            <select id="studentShoolYear" class="form-control" name="studentShoolYear" required>
              <?php $__currentLoopData = $schoolYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($sy->id); ?>" <?php echo e(changeSelectedStatus(old('studentShoolYear'),"$sy->id")); ?>><?php echo e($sy->course); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group col-md-3">
            <label for="studentClass" class="col-md-4 common-label-inline">Lớp <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
            <select id="studentClass" class="form-control" name="studentClass" required>
              <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($sy->id); ?>" <?php echo e(changeSelectedStatus(old('studentClass'),"$sy->id")); ?>><?php echo e($sy->class_name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
        </div>
        
        <div class="col-md-12 pl-0">
          <a data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
            Tìm kiếm nâng cao
          </a>
        </div>

        <div class="collapse <?php if( session()->has('_old_input') ): ?> show <?php endif; ?>" id="collapseExample">
          <div class="form-row">

            
            <div class="form-group col-md-3">
                <label for="filterSid">MSSV:</label>
            <input type="number" name="filterSid" id="filterSid" class="form-control" placeholder="Nhập MSSV..." value="<?php echo e(old('filterSid')); ?>">
              </div>

            
            <div class="form-group col-md-3">
              <label for="filterName">Họ tên:</label>
              <input type="text" name="filterName" id="filterName" class="form-control" placeholder="Nhập họ tên..." value="<?php echo e(old('filterName')); ?>">
            </div>
            
            <div class="form-group col-md-3">
              <label for="filterSex">Giới tính:</label>
              <select name="filterSex" id="filterSex" class="form-control">
                <option value="0" <?php echo e(changeSelectedStatus(old('filterSex'),'0')); ?>>Chọn giới tính</option>
                <option value="1" <?php echo e(changeSelectedStatus(old('filterSex'),'1')); ?>>Nam</option>
                <option value="2" <?php echo e(changeSelectedStatus(old('filterSex'),'2')); ?>>Nữ</option>
                <option value="3" <?php echo e(changeSelectedStatus(old('filterSex'),'3')); ?>>Khác</option>
              </select>
            </div>
            
            <div class="form-group col-md-3">
                <label for="filterAddress">Quê quán:</label>
                <select name="filterAddress" id="filterAddress" class="form-control">
                    <option value="0" <?php echo e(changeSelectedStatus(old('filterAddress'),'0')); ?>>Chọn quê quán</option>
                  <?php $__currentLoopData = $province; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pro->id); ?>" <?php echo e(changeSelectedStatus(old('filterAddress'),"$pro->id")); ?>><?php echo e($pro->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
          </div>
        </div>
        <div class="form-group col-md-2 offset-md-10">
            <button type="submit" class="btn btn-primary right"><i class="fas fa-filter"></i> Lọc</button>
          </div>
      </form>
    </div>
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <!-- Begin Page Content -->      
      <!-- DataTales Example -->
      <div class="card mb-4">
        
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
              <thead style="background: #f8f9fc">
                <tr>
                  <th></th>
                  <th>MSSV</th>
                  <th>Họ Tên</th>
                  <th>Khóa</th>
                  <th>Lớp</th>
                  <th>Giới tính</th>
                  <th>Ngày sinh</th>
                  <th>Tình trạng</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $studentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="">
                  <td><input type="hidden" value="<?php echo e($list->student_id); ?>"></td>
                  <td><?php echo e($list->student_id); ?></td>
                  <td><?php echo e($list->name); ?></td>
                  <td><?php echo e($list->schoolYear->course); ?></td>
                  <td><?php echo e($list->class->class_name); ?></td>
                  <td><?php echo changeGenderForList($list->sex); ?></td>
                  <td><?php echo e(date('d/m/Y',strtotime($list->birthday))); ?></td>
                  <td class="text-center"><?php echo changeStudyStatus($list->is_study); ?></td>
                  <td class="text-center">
                    <a class="cm-label text-info detailToggle" data-id="<?php echo e($list->student_id); ?>" data-toggle="modal"><i class="fas fa-list" title="Chi tiết"></i></a>
                    <a href="<?php echo e(route('get_edit_student',['id'=>$list->student_id])); ?>"><i class="fas fa-edit cm-label text-primary" title="Chỉnh sửa"></i></a>
                    
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <!-- /.container-fluid -->
      <a class="btn btn-success" href="<?php echo e(route('get_add_student')); ?>"><i class="fas fa-plus-circle"></i> Thêm 1 sinh viên</a>
      <a class="btn btn-info" href="<?php echo e(route('get_import_student')); ?>"><i class="fas fa-file-import"></i> Import Sinh viên</a>
      <button onclick="deleteStudent()" class="btn" id="deleteUser" style="background-color: #D98880; color: #fff"><i class="fas fa-minus-circle"></i> Xóa</button>
  </div>
</div>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal animated jackInTheBox" id="studentDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  
</div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('assets/vendor/datatables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datatables/js/dataTables.select.min.js')); ?>"></script>

<script>
  var classes = <?php echo $class; ?>;
  var BASE_URL = "<?php echo e(asset('admin/student/')); ?>"
</script>
<!-- Page level custom scripts -->
<script src="<?php echo e(asset('assets/js/admin/student_list.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>