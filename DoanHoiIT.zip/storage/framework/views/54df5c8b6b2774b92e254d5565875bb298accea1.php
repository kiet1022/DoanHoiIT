<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/excel_export_template/marks.blade.php */ ?>
<table>
    <thead>
    <tr>
        <th>MSSV</th>
        <th>Mã hoạt động</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($detail->student_id); ?></td>
            <td><?php echo e($detail->checkin_id); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>