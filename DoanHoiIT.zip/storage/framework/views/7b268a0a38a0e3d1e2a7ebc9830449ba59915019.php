<?php $__env->startSection('title','Điểm danh chương trình'); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/admin/activity/list_activity.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="row">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Điểm danh</li>
        </ol>
    </nav>
</div>
  <div class="row">
    <div class="col page-title-header">
      <h4>Điểm danh</h4>
    </div>
  </div>
  <div class="row">
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
        <div class="form-row">
          
          <div class="form-group col-md-4">
            <label for="year" class="col-md-4 common-label-inline">Năm học:</label>
            <div class="col-md-8 col-sm-8 col-xs-8 px-0">
              <select name="year" id="year" class="form-control">
                <option value="<?php echo e($year->name); ?>"><?php echo e($year->name); ?></option>
                </select>
              </div>
            </div>
            
            
            <div class="form-group col-md-4">
              <label for="activity" class="col-md-4 common-label-inline">Chương trình:</label>
              <div class="col-md-8 col-sm-8 col-xs-8 px-0">
                <select name="activity" id="activity" class="form-control">
                  <option value="">Chọn chương trình</option>
                  <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($a->id); ?>"><?php echo e($a->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            </div>

            
            <div class="form-group col-md-4">
              <label for="type" class="col-md-4 common-label-inline">Hình thức:</label>
              <div class="col-md-8 col-sm-8 col-xs-8 px-0">
                <select name="type" id="type" class="form-control">
                  <option value="">Chọn hình thức điểm danh</option>
                  <option value="0">Điểm danh sinh viên</option>
                  <option value="1">Điểm danh BTC</option>
                  <option value="2">Điểm danh CTV</option>
                </select>
              </div>
            </div>
            
          </div>
      </div>
      
      <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
        <div class="row">
          <div class="col-md-4">
              <div class="card mb-4">
                  <div class="card-body">
                      <div class="form-group">
                        <input type="number" class="form-control" id="inputsid" placeholder="Nhập MSSV sau đó nhấn Enter" min="1" max="99999999">
                      </div>
                  </div>
                </div>
          </div>
          <div class="col-md-8">
            <!-- Begin Page Content -->
            <div class="card mb-4">
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
                    <thead style="background: #f8f9fc">
                      <tr>
                        <th>STT</th>
                        <th>MSSV</th>
                        <th>Tên Sinh viên</th>
                        <th>Thời gian checkin</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div class="text-right">
              <button class="btn btn-primary" id="saveinfo" onclick="saveCheckin()"><i class="fas fa-download"></i> Lưu danh sách điểm danh</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <div class="col-md-12">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb cm-breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
          
        </ol>
      </nav>
    </div>
    <!-- Modal -->
    <div class="modal animated jackInTheBox" id="activityDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
      
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('js'); ?>
    <!-- Page level plugins -->

    <script>
      var BASE_URL = "<?php echo e(asset('admin/activities/')); ?>";
      var students = <?php echo $students; ?>;
    </script>
    <script src="<?php echo e(asset('assets/js/admin/activity/check_in.js')); ?>"></script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/activity/check_in.blade.php */ ?>