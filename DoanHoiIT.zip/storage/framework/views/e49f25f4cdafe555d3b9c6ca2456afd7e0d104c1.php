<?php /* D:\xampp\htdocs\DoanHoi\resources\views/admin/trash/student_table_trash.blade.php */ ?>
<thead style="background: #f8f9fc">
    <tr>
        <th></th>
        <th>MSSV</th>
        <th>Họ Tên</th>
        <th>Khóa</th>
        <th>Lớp</th>
        <th>Giới tính</th>
        <th>Ngày sinh</th>
        <th>Tình trạng</th>
        <th></th>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $studentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="">
        <td><input type="hidden" value="<?php echo e($list->student_id); ?>"></td>
        <td><?php echo e($list->student_id); ?></td>
        <td><?php echo e($list->name); ?></td>
        <td><?php echo e($list->schoolYear->course); ?></td>
        <td><?php echo e($list->class->class_name); ?></td>
        <td><?php echo changeGenderForList($list->sex); ?></td>
        <td><?php echo e(date('d/m/Y',strtotime($list->birthday))); ?></td>
        <td class="text-center"><?php echo changeStudyStatus($list->is_study); ?></td>
        <td class="text-center">
            <a class="cm-label text-info detailToggle" data-id="<?php echo e($list->student_id); ?>" data-toggle="modal"><i class="fas fa-list" title="Chi tiết"></i></a>
            <a href="<?php echo e(route('get_edit_student',['id'=>$list->student_id])); ?>"><i class="fas fa-edit cm-label text-primary" title="Chỉnh sửa"></i></a>
            
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>