<?php $__env->startSection('title', 'Dự trù kinh phí'); ?>
<?php $__env->startSection('style'); ?>
<style>
  td.details-control {
    background: url('../../../assets/img/details_open.png') no-repeat center center;
    cursor: pointer;
  }
  tr.shown td.details-control {
    background: url('../../../assets/img/details_close.png') no-repeat center center;
  }
  
  tr.shown>tr {
    background: #fff;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="row">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
                <li class="breadcrumb-item"><i class="fas fa-angle-right"></i> Quản lý dự trù</li>
                <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Danh sách dự trù</li>
            </ol>
        </nav>
    </div>
  <div class="row">
    <div class="col page-title-header">
      <h4>Dự trù kinh phí</h4>
    </div>
  </div>
  <div class="row">
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <form action="<?php echo e(route('filter_activity_fund')); ?>" method="POST" class="col-md-12" id="filterActivity">
        <?php echo csrf_field(); ?>
        <div class="form-row">
          
          <div class="form-group col-md-4">
            <label for="year" class="col-md-12 common-label-inline">Năm học:</label>
            <div class="col-md-8 col-sm-8 col-xs-8 px-0">
              <select name="year" id="year" class="form-control">
                <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($y->name); ?>" <?php echo changeSelectedStatus($y->name, old('year') ); ?>><?php echo e($y->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          
          
          <div class="form-group col-md-4">
            <label for="semester" class="col-md-12 common-label-inline">Học kỳ:</label>
            <div class="col-md-8 col-sm-8 col-xs-8 px-0">
              <select name="semester" id="semester" class="form-control">
                <option value="">Chọn học kỳ</option>
                <option value="1" <?php echo changeSelectedStatus("1", old('semester') ); ?>>Kỳ 1</option>
                <option value="2" <?php echo changeSelectedStatus("2", old('semester') ); ?>>Kỳ 2</option>
              </select>
            </div>
          </div>
          
          
          <div class="form-group col-md-4">
            <label for="activity" class="col-md-12 common-label-inline">Chương trình:</label>
            <div class="col-md-8 col-sm-8 col-xs-8 px-0">
              <select name="activity" id="activity" class="form-control">
                <option value="">Chọn chương trình</option>
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($a->id); ?>" <?php echo changeSelectedStatus("$a->id", old('activity') ); ?>><?php echo e($a->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
          </div>
          
        </div>
        <div class="form-group col-md-2 offset-md-10">
          <button type="submit" class="btn btn-primary right"><i class="fas fa-filter"></i> Lọc</button>
        </div>
      </form>
    </div>
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <!-- Begin Page Content -->      
      <!-- DataTales Example -->
      <div class="card mb-4">
        
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
              <thead style="background: #f8f9fc">
                <tr>
                  <th></th>
                  <th>Chi tiết</th>
                  <th></th>
                  <th>Mã dự trù</th>
                  <th>Chương trình</th>
                  <th>Tổng kinh phí (dự kiến)</th>
                  <th>Thực chi</th>
                  <th>Trạng thái</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $funds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fund): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td></td>
                <td></td>
                <td><?php echo $fund->details; ?></td>
                <td><?php echo e($fund->id); ?></td>
                <td><?php echo e($fund->activity->name); ?></td>
                <td><?php echo e(number_format($fund->initial_funds)); ?> đ</td>
                <td><?php echo e(number_format($fund->actual_funds)); ?> đ</td>
                <td class="text-center"><?php echo changePayedStatus($fund->status); ?></td>
                <td class="text-center">
                  <a href="<?php echo e(route('get_edit_activity_funding',['id'=>$fund->id])); ?>" class="btn btn-primary btn-sm text-center"><i class="fas fa-edit" title="Chỉnh sửa dự trù" data-toggle="tooltip" data-placement="top"></i></a>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <button onclick="deleteActivity()" class="btn" id="deleteFund" style="background-color: #D98880; color: #fff"><i class="fas fa-minus-circle"></i> Xóa dự trù</button>
    </div>
  </div>
  
  <div class="col-md-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb cm-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
        
      </ol>
    </nav>
  </div>
  <!-- Modal -->
  <div class="modal animated jackInTheBox" id="activityDetail" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    
  </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <!-- Page level plugins -->
  
  <script>
    var BASE_URL = "<?php echo e(asset('admin/activities/funding')); ?>";
  </script>
  <script src="<?php echo e(asset('assets/js/admin/fund/list_activity_fund.js')); ?>"></script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/funding/list_activity_fund.blade.php */ ?>