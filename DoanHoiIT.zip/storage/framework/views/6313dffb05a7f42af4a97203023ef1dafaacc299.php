<?php $__env->startSection('title'); ?>
Chỉnh sửa bài viết
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/admin/cm-news.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="row">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
                <li class="breadcrumb-item"><i class="fas fa-angle-right"></i> Quản lý tin tức</li>
                <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('get_news_list')); ?>"> Danh sách tin tức</a></li>
                <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Sửa tin tức</li>
            </ol>
        </nav>
    </div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
        <form action="<?php echo e(route('post_edit_new',['id'=>$news->id])); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="col-md-6 col-sm-12">
                    <div class="card">
                        <div class="card-body">       
                            <div class="form-group cm-inline-form">
                                <label for="type" class=" common-label-inline">Thể loại <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <select id="type" class="form-control " name="type">
                                    <?php $__currentLoopData = $newsType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo $type->id; ?>" <?php if($news->type_id == $type->id): ?> <?php echo e("selected"); ?> <?php endif; ?>><?php echo e($type->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group cm-inline-form">
                                <label for="title" class=" common-label-inline">Tiêu đề <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <input type="text" class="form-control " id="title" name="title" placeholder="" required value="<?php echo e($news->title); ?>">
                            </div>                     
                            <div class="form-group cm-inline-form">
                                <label for="sumary" class=" common-label-inline">Tóm tắt:</label>
                                <textarea class="form-control" id="sumary" name="sumary" style="margin-top: 0px; margin-bottom: 0px; height: 139px;"><?php echo e($news->sumary); ?></textarea>
                            </div>
                            <div class="form-group cm-inline-form select-image">
                                <label  class=" common-label-inline">Hình ảnh nổi bật:</label>
                                <input type="file" name="image" id="image" onchange="loadFile(event)" accept='image/*' style="height: auto;" class="form-control">
                                <?php if($news->image != ""): ?> 
                                <img id="myImg" class="rounded image-new" src="<?php echo e(asset('images/news')); ?>/<?php echo e($news->image); ?>" style="width: 30%; margin-top: 10px">
                                
                                <div class="form-group cm-inline-form" id="selectImage"></div>
                                <?php else: ?>
                                <img id="myImg" class="rounded image-new" style="width: 30%; margin-top: 10px; display: none;">
                                <?php endif; ?>
                                <div id="myModal" class="modal">
                                        <span class="close">&times;</span><!-- The Close Button -->
                                        <img class="modal-content" id="img01"><!-- Modal Content (The Image) -->
                                        <div id="caption"></div><!-- Modal Caption (Image Text) -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6 col-sm-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-group cm-inline-form">
                                <label for="content_news" class="common-label-inline">Nội dung <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <textarea id="content_news" name="content_news"><?php echo e($news->content); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <hr class="sidebar-divider">
            <div class="col-12 text-center">
                <button type="button" class="btn btn-secondary cm-btn-form" onclick="javascript:history.back()">Cancel</button>
                <button type="submit" class="btn btn-success cm-btn-form">Submit</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">
    //replace textarea
    if(CKEDITOR) {
        CKEDITOR.replace('content_news', {
            allowedContent: true
        });
        CKEDITOR.config.extraAllowedContent = 'audio[*]';
        CKEDITOR.config.height = 350;
        CKEDITOR.config.width = 350;
    }
    <?php if(session('error')): ?>
    var error = "<?php echo e(session('error')); ?>";
    showNotify('error',error);
    <?php endif; ?>
    <?php if(session('success')): ?>
    var success = "<?php echo e(session('success')); ?>";
    showNotify('success',success);
    <?php endif; ?>
</script>
<script type="text/javascript">
    // Get the modal zoom image
    var modal = document.getElementById('myModal');
    
    // Get the image and insert it inside the modal - use its "alt" text as a caption
    var img = document.getElementById('myImg');
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function(){
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
    
    // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];
        
        // When the user clicks on <span> (x), close the modal
            span.onclick = function() { 
                modal.style.display = "none";
            }
        </script>
        <script src="<?php echo e(asset('assets/js/admin/news.js')); ?>"></script>
        
        <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/news/edit_new.blade.php */ ?>