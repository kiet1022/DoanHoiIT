<?php $__env->startSection('title', 'Dự trù kinh phí'); ?>
<?php $__env->startSection('style'); ?>
<style>
  table.dataTable tr th.select-checkbox.selected::after {
    content: "✔";
    margin-top: -11px;
    margin-left: -4px;
    text-align: center;
    text-shadow: rgb(176, 190, 217) 1px 1px, rgb(176, 190, 217) -1px -1px, rgb(176, 190, 217) 1px -1px, rgb(176, 190, 217) -1px 1px;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="row">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><i class="fas fa-home"></i><a href="<?php echo e(route('admin_dashboard')); ?>"> Dashboard</a></li>
                <li class="breadcrumb-item"><i class="fas fa-angle-right"></i> Quản lý Users</li>
                <li class="breadcrumb-item active" aria-current="page"><i class="fas fa-angle-right"></i> Danh sách quyền</li>
            </ol>
        </nav>
    </div>
  <div class="row">
    <div class="col page-title-header">
      <h4>Danh sách quyền truy cập</h4>
    </div>
  </div>
  <div class="row">
    
    
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
      <!-- Begin Page Content -->      
      <!-- DataTales Example -->
      <div class="card mb-4">
        
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover" id="dataTable" width="100%" cellspacing="0">
              <thead style="background: #f8f9fc">
                <tr>
                  <th></th>
                  <th>Mã quyền</th>
                  <th>Tên quyền</th>
                  <th>Mô tả</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="">
                      <td></td>
                      <td><?php echo e($role->id); ?></td>
                      <td><?php echo e($role->name); ?></td>
                      <td><?php echo e($role->description); ?></td>
                      <td class="text-center">
                      <a class="edit-roles" data-content="<?php echo e($role); ?>"><i class="fas fa-edit cm-label text-primary" title="Chỉnh sửa quyền" data-toggle="tooltip" data-placement="top"></i></a>
                      </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <button class="btn btn-success" data-toggle="modal" data-target="#addNewModal"><i class="fas fa-plus-circle"></i> Thêm quyền</button>
      <button onclick="deleteActivity()" class="btn" id="deleteFund" style="background-color: #D98880; color: #fff"><i class="fas fa-minus-circle"></i> Xóa quyền</button>
    </div>
  </div>
  
  <div class="col-md-12">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb cm-breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
        
      </ol>
    </nav>
  </div>

  <!-- The edit Modal -->
  <div class="modal fade" id="editModal">
    <div class="modal-dialog modal-lg">
      <form action="<?php echo e(route('edit_role')); ?>" method="POST">
        <?php echo csrf_field(); ?>
          <div class="modal-content">
  
              <!-- Modal Header -->
              <div class="modal-header">
                <h4 class="modal-title">Chỉnh sửa quyền</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
              </div>
              
              <!-- Modal body -->
              <div class="modal-body" id="content-body">

              </div>
              
              <!-- Modal footer -->
              <div class="modal-footer">
                <button type="submit" class="btn btn-success cm-btn-form">Lưu</button>
                <button type="button" class="btn btn-warning cm-btn-form" data-dismiss="modal">Đóng</button>
              </div>
              
            </div>
      </form>
    </div>
  </div>


    <!-- The add new Modal -->
    <div class="modal fade" id="addNewModal">
        <div class="modal-dialog modal-lg">
          <form action="<?php echo e(route('add_role')); ?>" method="POST">
            <?php echo csrf_field(); ?>
              <div class="modal-content">
      
                  <!-- Modal Header -->
                  <div class="modal-header">
                    <h4 class="modal-title">Thêm quyền</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                  </div>
                  
                  <!-- Modal body -->
                  <div class="modal-body" id="content-body">
                      <div class="form-group">
                          <label for="name">Tên quyền <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                          <input class="form-control" type="text" name="name" id="name" placeholder="Nhập tên quyền" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Mô tả <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                            <textarea class="form-control" name="description" id="description" cols="30" rows="10" required></textarea>
                        </div>
                  </div>
                  
                  <!-- Modal footer -->
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-success cm-btn-form">Lưu</button>
                    <button type="button" class="btn btn-warning cm-btn-form" data-dismiss="modal">Đóng</button>
                  </div>
                  
                </div>
          </form>
        </div>
      </div>
  <?php $__env->stopSection(); ?>
  <?php $__env->startSection('js'); ?>
  <!-- Page level plugins -->
  
  <script>
    var BASE_URL = "<?php echo e(asset('admin/activities/funding')); ?>";
  </script>
  <script>
      <?php if(session('error')): ?>
      var error = "<?php echo e(session('error')); ?>";
      showNotify('error',error);
      <?php endif; ?>
      <?php if(session('success')): ?>
      var success = "<?php echo e(session('success')); ?>";
      showNotify('success',success);
      <?php endif; ?>
  </script>
  <script src="<?php echo e(asset('assets/js/admin/user/roles_list.js')); ?>"></script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/admin/user/roles_list.blade.php */ ?>