<!DOCTYPE html>
<html lang="en">
<head>
     
     <title><?php echo $__env->yieldContent('title'); ?></title>
     <meta charset="UTF-8">
     <meta http-equiv="X-UA-Compatible" content="IE=Edge">
     <meta name="description" content="">
     <meta name="keywords" content="">
     <meta name="author" content="">
     <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
     <link rel="shortcut icon" href="<?php echo e(asset('assets/img/faculty_banner.png')); ?>"> 
     <base href="<?php echo e(asset('')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/bootstrap-3.3.6/dist/css/bootstrap.min.css')); ?>">
     <link rel="stylesheet" href="pages/css/font-awesome.min.css">
     <link rel="stylesheet" href="pages/css/owl.carousel.css">
     <link rel="stylesheet" href="pages/css/owl.theme.default.min.css">
     <!-- MAIN CSS -->
     <link rel="stylesheet" href="pages/css/templatemo-style.css">
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/userinfo.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/animate.css-master/animate.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('pages/css/font-awesome.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap4-dialog/css/bootstrap-dialog.min.css')); ?>" >
     <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/datepicker-master/dist/datepicker.css')); ?>">
     <style>
          .dropdown:hover .dropdown-menu {
               display: block;
          }
     </style>
     <?php echo $__env->yieldContent('style'); ?>
</head>
<body id="top" data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
     <!-- MENU -->
     <?php echo $__env->make('student.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- HOME -->
     <?php echo $__env->yieldContent('extends'); ?>
     <section style="padding-top: 20px; padding-bottom: 20px;" id="register">
          <?php echo $__env->yieldContent('breadcrumb'); ?>
          <div class="container">
               <div class="row profile">
                    <?php echo $__env->make('student.layout.usersidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo $__env->yieldContent('content'); ?>
               </div>
          </div>
     </section>
     <!-- ABOUT -->
     <!-- FOOTER -->
     <?php echo $__env->make('student.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
     <!-- SCRIPTS -->
     <script src="pages/js/jquery.js"></script>
     <script src="<?php echo e(asset('pages/css/bootstrap-3.3.6/dist/js/bootstrap.min.js')); ?>"></script>
     <script src="pages/js/owl.carousel.min.js"></script>
     <script src="pages/js/smoothscroll.js"></script>
     <script src="pages/js/custom.js"></script>
     <script src="<?php echo e(asset('assets/vendor/bootstrap-notify-master/bootstrap-notify.min.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/bootstrap4-dialog/js/bootstrap-dialog.min.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/jquery.blockUI.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/js/common.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/datepicker-master/dist/datepicker.js')); ?>"></script>
     <script src="<?php echo e(asset('assets/vendor/datepicker-master/i18n/datepicker.vi-VN.js')); ?>"></script>
     <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /* D:\xampp\htdocs\DoanHoiIT\resources\views/student/layout/userindex.blade.php */ ?>