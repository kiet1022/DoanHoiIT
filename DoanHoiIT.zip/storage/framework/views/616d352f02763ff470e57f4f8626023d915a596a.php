<?php /* D:\xampp\htdocs\DoanHoi\resources\views/admin/activity/add_activity.blade.php */ ?>
<?php $__env->startSection('title','Thêm hoạt động'); ?>
<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/admin/common.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('assets/vendor/icheck-1.x/skins/flat/green.css')); ?>" rel="stylesheet">
<link href="https://gitcdn.github.io/bootstrap-toggle/2.2.2/css/bootstrap-toggle.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/datepicker-master/dist/datepicker.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_content'); ?>
<div class="row">
    <div class="col page-title-header">
        <h4>Nhập thông tin chương trình</h4>
    </div>
</div>
<div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12 custom_panel">
        <form action="<?php echo e(route('post_add_activity')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <b>Thông tin chương trình</b>
                        </div>
                        <div class="card-body">
                            
                            <div class="form-inline cm-inline-form">
                                <label for="name" class="col-md-6 common-label-inline">Tên chương trình <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <input type="text" class="form-control col-md-6" id="name" name="name" placeholder="Tên chương trình" required value="<?php echo e(old('name')); ?>">
                            </div>
                            
                            
                            <?php if($errors->get('name')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="year" class="col-md-6 common-label-inline">Năm học <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <select id="year" class="form-control col-md-6" name="year" required >
                                <?php $__currentLoopData = $year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($y->name); ?>"><?php echo e($y->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            
                            <?php if($errors->get('year')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('year'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($year); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="semester" class="col-md-6 common-label-inline">Học kỳ <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <select id="semester" class="form-control col-md-6" name="semester" required >
                                    <option value="1">Kỳ 1</option>
                                    <option value="2">Kỳ 2</option>
                                </select>
                            </div>

                            
                            <?php if($errors->get('name')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($name); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="leader" class="col-md-6 common-label-inline">Đứng chính <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <select id="leader" class="form-control col-md-6" name="leader" required >
                                <?php $__currentLoopData = $leader; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($l['student_id']); ?>"><?php echo e($l['name']); ?> - <?php echo changeLevelLabel($l['level'],$l['type']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            
                            <?php if($errors->get('leader')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('leader'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leader): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($leader); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="startDate" class="col-md-6 common-label-inline">Ngày bắt đầu chương trình <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <div class="col-md-6 px-0">
                                        <input style="width: inherit;" id="startDate" width="100%" class="form-control" name="startDate" maxlength="10" required value="<?php echo e(old('startDate')); ?>"  >
                                </div>
                            </div>
                            
                            
                            <?php if($errors->get('startDate')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('startDate'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $startDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($startDate); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="endDate" class="col-md-6 common-label-inline">Ngày kết thúc chương trình <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <div class="col-md-6 px-0">
                                        <input style="width: inherit;" id="endDate" width="100%" class="form-control" name="endDate" maxlength="10" required value="<?php echo e(old('endDate')); ?>"  >
                                </div>
                            </div>
                            
                            
                            <?php if($errors->get('endDate')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('endDate'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($endDate); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="startRegisDate" class="col-md-6 common-label-inline">Ngày bắt đầu đăng ký <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <div class="col-md-6 px-0">
                                        <input style="width: inherit;" id="startRegisDate" width="100%" class="form-control" name="startRegisDate" maxlength="10" required value="<?php echo e(old('startRegisDate')); ?>"  >
                                </div>
                            </div>
                            
                            
                            <?php if($errors->get('startRegisDate')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('startRegisDate'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $startRegisDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($startRegisDate); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="endRegisDate" class="col-md-6 common-label-inline">Ngày kết thúc đăng ký <small class="common-required" data-toggle="tooltip" data-placement="top" title="Bắt buộc">(*)</small>:</label>
                                <div class="col-md-6 px-0">
                                        <input style="width: inherit;" id="endRegisDate" width="100%" class="form-control" name="endRegisDate" maxlength="10" required value="<?php echo e(old('endRegisDate')); ?>"  >
                                </div>
                            </div>
                            
                            
                            <?php if($errors->get('endRegisDate')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('endRegisDate'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endRegisDate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($endRegisDate); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="maxRegisNum" class="col-md-6 common-label-inline">Số lượng tham gia:</label>
                                <input type="number" class="form-control col-md-6" id="maxRegisNum" name="maxRegisNum" placeholder="Số lượng sinh viên tham gia" value="<?php echo e(old('maxRegisNum')); ?>">
                            </div>
                            
                            
                            <?php if($errors->get('maxRegisNum')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('maxRegisNum'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maxRegisNum): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($maxRegisNum); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="practiseMark" class="col-md-6 common-label-inline">Điểm rèn luyện:</label>
                                <input type="number" class="form-control col-md-6" id="practiseMark" name="practiseMark" placeholder="Điểm rèn luyện" value="<?php echo e(old('practiseMark')); ?>">
                            </div>
                            
                            
                            <?php if($errors->get('practiseMark')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('practiseMark'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practiseMark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($practiseMark); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            
                            <div class="form-inline cm-inline-form">
                                <label for="socialMark" class="col-md-6 common-label-inline">Điểm CTXH:</label>
                                <input type="number" class="form-control col-md-6" id="socialMark" name="socialMark" placeholder="Điểm CTXH" value="<?php echo e(old('socialMark')); ?>">
                            </div>
                            
                            
                            <?php if($errors->get('socialMark')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-6 offset-md-6 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('socialMark'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialMark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($socialMark); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <b>Nội dung chương trình</b>
                        </div>
                        <div class="card-body">
                            <div class="form-inline cm-inline-form">
                                <label for="activityContent" class="col-md-6 col-sm-4 col-xs-4 common-label-inline">Nội dung:</label>
                                <textarea id="activityContent" name="activityContent"></textarea>
                            </div>

                            <div class="form-inline cm-inline-form">
                                <label for="planUrl" class="col-md-6 common-label-inline">Upload file kế hoạch:</label>
                            <input type="file" name="planUrl" id="planUrl" class="col-md-12 col-xs-12 col-sm-12 form-control" style="height: auto;" value="<?php echo e(old('planUrl')); ?>">
                            </div>
                            
                            <?php if($errors->get('planUrl')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-12 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('planUrl'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $planUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($planUrl); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>

                            <div class="form-inline cm-inline-form">
                                <label for="fundUrl" class="col-md-6 common-label-inline">Upload file dự trù:</label>
                                <input type="file" name="fundUrl" id="fundUrl" class="col-md-12 col-xs-12 col-sm-12 form-control" style="height: auto;" value="<?php echo e(old('fundUrl')); ?>">
                            </div>
                            
                            <?php if($errors->get('fundUrl')): ?>
                            <div class="form-inline cm-inline-form cm-error">
                                <ul class="col-md-12 cm-ul-error">
                                    <?php $__currentLoopData = $errors->get('fundUrl'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fundUrl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($fundUrl); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div> 
                </div>
            </div>
            <hr class="sidebar-divider">
            <div class="col-12 text-center">
                <button type="submit" class="btn btn-success cm-btn-form">Submit</button>
                <button id="clear" onclick="clearValue()" type="button" class="btn btn-warning cm-btn-form">Clear</button>
            </div>
        </form>
    </div>
    
    <div class="col-md-12">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb cm-breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(URL::previous()); ?>" class="cm-breadcrumb-a"><i class="fas fa-arrow-circle-left"></i> Quay lại</a></li>
                
            </ol>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('assets/vendor/icheck-1.x/icheck.js')); ?>"></script>
<script src="https://gitcdn.github.io/bootstrap-toggle/2.2.2/js/bootstrap-toggle.min.js"></script>
<script src="<?php echo e(asset('assets/vendor/datepicker-master/dist/datepicker.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/datepicker-master/i18n/datepicker.vi-VN.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/ckeditor/ckeditor.js')); ?>"></script>
<script>
    <?php if(session('error')): ?>
        var error = "<?php echo e(session('error')); ?>";
        showNotify('error',error);
    <?php endif; ?>
    <?php if(session('success')): ?>
        var success = "<?php echo e(session('success')); ?>";
        showNotify('success',success);
    <?php endif; ?>
</script>
<script src="<?php echo e(asset('assets/js/admin/activity/add_activity.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>